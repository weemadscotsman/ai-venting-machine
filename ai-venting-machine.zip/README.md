# 🎮 CANN.ON.AI VENTING MACHINE v4.0

> *Game Dev Team vs. Sci-Fi AI. Stream-safe and secure.*

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new)

![Version](https://img.shields.io/badge/version-4.0-red)
![Security](https://img.shields.io/badge/security-STREAM--SAFE-green)

## 🔒 SECURITY FIRST

**NEVER** expose API keys in browser. This architecture uses a backend proxy to keep keys secure.

```
┌─────────────┐      ┌──────────────┐      ┌──────────┐
│   Browser   │──────▶│ Proxy Server │──────▶│   LLM    │
│  (No keys!) │      │ (Keys here)  │      │ (Kimi/   │
└─────────────┘      └──────────────┘      │ Gemini)  │
                                           └──────────┘
```

### Architecture

| Component | Responsibility | API Keys? |
|-----------|---------------|-----------|
| **Frontend** | UI, state, spectator mode | ❌ NEVER |
| **Proxy** | LLM routing, rate limiting, caching | ✅ Server-side only |
| **LLM Provider** | Generate chaos | Backend access only |

---

## 🚀 Quick Start

### 1. Start the Proxy (Backend)

```bash
cd api

# Set your API key (Moonshot/Kimi recommended)
set MOONSHOT_API_KEY=sk-your-key-here

# Or Gemini
set GEMINI_API_KEY=your-key-here

# Start proxy
node proxy.cjs
```

Proxy runs on http://localhost:3002

### 2. Start the Frontend

```bash
# In another terminal
npm install
npm run dev
```

Frontend runs on http://localhost:3000

### 3. Configure & Test

1. Open http://localhost:3000
2. Click **⚙️ Config**
3. Select **"🔒 Secure Proxy (Recommended)"**
4. Click **TEST** to verify connection
5. **PULL THE LEVER!**

---

## ⚠️ INSECURE MODE (Browser)

**WARNING:** Only for local testing! API keys exposed to browser are visible to anyone watching.

If you MUST use browser mode:
1. Settings → Select provider (Gemini/OpenAI/etc)
2. Enter API key (stored in localStorage - insecure!)
3. Never use this for streaming

---

## 🛠️ Configuration

### Environment Variables (Proxy)

```bash
# Choose ONE provider:
MOONSHOT_API_KEY=sk-...        # Recommended
GEMINI_API_KEY=AIza...         # Alternative  
OPENAI_API_KEY=sk-...          # Alternative
ANTHROPIC_API_KEY=sk-ant...    # Alternative

# Optional:
PORT=3002                      # Proxy port
```

### Frontend Settings

Settings are stored in localStorage (safe - no API keys):
- `provider`: PROXY | LOCAL | GEMINI | etc
- `proxyUrl`: http://localhost:3002
- `model`: auto (proxy decides)

---

## 🎮 Features

### Secure by Default
- ✅ API keys never touch browser
- ✅ Rate limiting (20 req/min)
- ✅ Circuit breaker (fails gracefully)
- ✅ Crisis caching (5 min TTL)

### Game Studio Chaos
- 8 Game Dev agents (Val, Scope Sam, Crunch Cody, etc.)
- 4 AI Chaos agents (H.E.R., SPINE, Mirrorvale, Coach Crystal)
- Weighted crisis selection with cooldowns
- Agent evolution & state drift

### Spectator Mode
```
http://localhost:3000?spectator=true
```
- Floating reactions (🔥😂💀)
- Live viewer simulation
- Share button

---

## 📁 File Structure

```
api/
└── proxy.cjs              # Secure backend (keys here)
src/
└── orchestrator/          # Standalone FSM
    └── ventOrchestrator.ts
services/
└── llmService.ts          # Proxy-only service
components/
├── SettingsModal.tsx      # Secure config UI
└── ...
```

---

## 🔥 What Was Fixed (v4 Audit Response)

| Issue | Before | After |
|-------|--------|-------|
| **API Key Storage** | In localStorage (stolen easily) | Server-side only |
| **Token Saver** | Fake claim (did nothing) | Removed (honest) |
| **Proxy Usage** | Ignored | Primary architecture |
| **Config Validation** | None | Health check endpoint |
| **Security Model** | Browser calls LLM directly | Proxy calls LLM |

---

## 📝 License

MIT License

**Built with paranoia and spite** 🔒💀
