/**
 * VENT MACHINE PROXY v3.3 - PERSISTENCE + MEMORY DECAY
 * 
 * FEATURES:
 * - Agent memory persists across server restarts
 * - Memory decay over time (agents forget old traumas)
 * - Session state saved to disk
 * - Automatic memory cleanup
 */

const http = require('http');
const https = require('https');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const CONFIG = {
  PORT: process.env.PORT || 3002,
  MOONSHOT_API_KEY: process.env.MOONSHOT_API_KEY || 'sk-bU4wUps8PWHO2OQZCSIsELYCi9W22wb0jOTNkWCgE4rnHrLD',
  
  // Memory settings
  MEMORY_DECAY_HOURS: 24,        // Memories fade after 24 hours
  MEMORY_SAVE_INTERVAL: 60000,   // Save every 60 seconds
  MAX_MEMORY_ENTRIES: 50,        // Max memories per agent
};

// DATA DIRECTORIES
const DATA_DIR = path.join(__dirname, '..', 'data');
const MEMORY_FILE = path.join(DATA_DIR, 'agent_memory.json');
const SESSION_FILE = path.join(DATA_DIR, 'session_state.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// IN-MEMORY STATE
const rateStore = new Map();
const newsCache = { data: null, time: 0, source: 'none' };

// AGENT MEMORY STRUCTURE:
// {
//   agentId: {
//     scars: [{ text, timestamp, severity }],
//     catchphrases: [{ text, timestamp }],
//     grudges: [{ target, reason, timestamp }],
//     philosophy: string,
//     lastCrisis: string,
//     totalWins: number,
//     totalLosses: number,
//     lastActive: timestamp,
//     relationshipMap: { agentId: score }
//   }
// }
let agentMemory = new Map();

// SESSION STATE
let sessionState = {
  totalCrises: 0,
  startTime: Date.now(),
  lastCrisisTime: null,
  globalEntropy: 50,
  epochCount: 0
};

// LOAD AGENT FILES (SOUL + GOALS + SKILLS)
const AGENT_SOULS = {};
const AGENT_GOALS = {};
const AGENT_SKILLS = {};

function loadAgentFiles() {
  const agentsDir = path.join(__dirname, '..', 'agents');
  
  // DYNAMICALLY DISCOVER ALL AGENT IDs from soul files
  const agentIds = [];
  try {
    const files = fs.readdirSync(agentsDir);
    files.forEach(file => {
      // Match files like "agent-id.md" (not -goals.md or -skills.md)
      const match = file.match(/^([a-z]+-[a-z]+-\d+)\.md$/);
      if (match && !file.includes('-goals') && !file.includes('-skills')) {
        agentIds.push(match[1]);
      }
    });
    console.log(`[Trinity] Discovered ${agentIds.length} agents: ${agentIds.join(', ')}`);
  } catch (e) {
    console.error('[Trinity] Failed to scan agents directory:', e.message);
    return;
  }
  
  let loadedCount = { soul: 0, goals: 0, skills: 0 };
  
  agentIds.forEach(id => {
    // Load soul
    try {
      const soulPath = path.join(agentsDir, `${id}.md`);
      if (fs.existsSync(soulPath)) {
        AGENT_SOULS[id] = fs.readFileSync(soulPath, 'utf8');
        loadedCount.soul++;
      } else {
        console.warn(`[Soul] Missing ${id}.md`);
      }
    } catch (e) {
      console.error(`[Soul] Failed ${id}:`, e.message);
    }
    
    // Load goals
    try {
      const goalsPath = path.join(agentsDir, `${id}-goals.md`);
      if (fs.existsSync(goalsPath)) {
        AGENT_GOALS[id] = fs.readFileSync(goalsPath, 'utf8');
        loadedCount.goals++;
      } else {
        console.warn(`[Goals] Missing ${id}-goals.md`);
      }
    } catch (e) {
      console.error(`[Goals] Failed ${id}:`, e.message);
    }
    
    // Load skills
    try {
      const skillsPath = path.join(agentsDir, `${id}-skills.md`);
      if (fs.existsSync(skillsPath)) {
        AGENT_SKILLS[id] = fs.readFileSync(skillsPath, 'utf8');
        loadedCount.skills++;
      } else {
        console.warn(`[Skills] Missing ${id}-skills.md`);
      }
    } catch (e) {
      console.error(`[Skills] Failed ${id}:`, e.message);
    }
  });
  
  console.log(`[Trinity] Loaded: ${loadedCount.soul} souls, ${loadedCount.goals} goals, ${loadedCount.skills} skills`);
}
loadAgentFiles();

// ==================== PERSISTENCE ====================

function saveAgentMemory() {
  try {
    const data = Object.fromEntries(agentMemory);
    fs.writeFileSync(MEMORY_FILE, JSON.stringify(data, null, 2));
    console.log(`[Persist] Saved ${agentMemory.size} agent memories`);
  } catch (e) {
    console.error('[Persist] Failed to save memory:', e.message);
  }
}

function loadAgentMemory() {
  try {
    if (fs.existsSync(MEMORY_FILE)) {
      const data = JSON.parse(fs.readFileSync(MEMORY_FILE, 'utf8'));
      agentMemory = new Map(Object.entries(data));
      
      // Apply decay to loaded memories
      applyMemoryDecay();
      
      console.log(`[Persist] Loaded ${agentMemory.size} agent memories`);
    }
  } catch (e) {
    console.error('[Persist] Failed to load memory:', e.message);
    agentMemory = new Map();
  }
}

function saveSessionState() {
  try {
    fs.writeFileSync(SESSION_FILE, JSON.stringify(sessionState, null, 2));
  } catch (e) {
    console.error('[Persist] Failed to save session:', e.message);
  }
}

function loadSessionState() {
  try {
    if (fs.existsSync(SESSION_FILE)) {
      sessionState = JSON.parse(fs.readFileSync(SESSION_FILE, 'utf8'));
      console.log(`[Persist] Loaded session: ${sessionState.totalCrises} crises recorded`);
    }
  } catch (e) {
    console.error('[Persist] Failed to load session:', e.message);
  }
}

// ==================== MEMORY DECAY ====================

function applyMemoryDecay() {
  const now = Date.now();
  const decayMs = CONFIG.MEMORY_DECAY_HOURS * 60 * 60 * 1000;
  let decayed = 0;
  
  for (const [agentId, memory] of agentMemory) {
    // Decay scars (old traumas fade)
    if (memory.scars) {
      const originalLength = memory.scars.length;
      memory.scars = memory.scars.filter(scar => {
        const age = now - scar.timestamp;
        // 50% chance to forget after decay period
        if (age > decayMs && Math.random() > 0.5) {
          decayed++;
          return false;
        }
        return true;
      });
    }
    
    // Decay grudges
    if (memory.grudges) {
      memory.grudges = memory.grudges.filter(grudge => {
        const age = now - grudge.timestamp;
        if (age > decayMs * 2 && Math.random() > 0.3) { // Grudges last longer
          decayed++;
          return false;
        }
        return true;
      });
    }
    
    // Limit catchphrases (only keep recent 10)
    if (memory.catchphrases && memory.catchphrases.length > 10) {
      memory.catchphrases = memory.catchphrases.slice(-10);
    }
    
    // Update last active
    memory.lastActive = now;
  }
  
  if (decayed > 0) {
    console.log(`[Memory] ${decayed} old memories decayed`);
  }
}

// Auto-save every minute
setInterval(() => {
  saveAgentMemory();
  saveSessionState();
}, CONFIG.MEMORY_SAVE_INTERVAL);

// ==================== AGENT MEMORY API ====================

function getAgentMemory(agentId) {
  if (!agentMemory.has(agentId)) {
    agentMemory.set(agentId, {
      scars: [],
      catchphrases: [],
      grudges: [],
      philosophy: '',
      lastCrisis: '',
      totalWins: 0,
      totalLosses: 0,
      lastActive: Date.now(),
      relationshipMap: {}
    });
  }
  return agentMemory.get(agentId);
}

function updateAgentMemory(agentId, result) {
  const mem = getAgentMemory(agentId);
  const now = Date.now();
  
  if (result.won) {
    mem.totalWins++;
    mem.catchphrases.push({
      text: result.catchphrase || 'Victory!',
      timestamp: now
    });
  } else {
    mem.totalLosses++;
    if (result.trauma) {
      mem.scars.push({
        text: result.trauma,
        timestamp: now,
        severity: result.severity || 5
      });
    }
  }
  
  if (result.grudge) {
    mem.grudges.push({
      target: result.grudgeTarget,
      reason: result.grudge,
      timestamp: now
    });
  }
  
  if (result.newPhilosophy) {
    mem.philosophy = result.newPhilosophy;
  }
  
  // Update relationships
  if (result.relationshipChanges) {
    for (const [target, delta] of Object.entries(result.relationshipChanges)) {
      mem.relationshipMap[target] = (mem.relationshipMap[target] || 0) + delta;
    }
  }
  
  mem.lastCrisis = result.crisis || mem.lastCrisis;
  mem.lastActive = now;
  
  // Limit memory size
  if (mem.scars.length > CONFIG.MAX_MEMORY_ENTRIES) {
    mem.scars = mem.scars.slice(-CONFIG.MAX_MEMORY_ENTRIES);
  }
}

// ==================== AGENT PERSONAS ====================

const AGENT_PERSONAS = {
  'visionary-01': {
    name: 'Val',
    speak: (crisis, stress) => stress > 80 
      ? `WE NEED TO PIVOT TO THE METAVERSE! ${crisis.headline} is our CHANCE!`
      : `What if we made the game ABOUT ${crisis.headline}? Revolutionary!`,
    quirks: ['metaverse', 'pivot', 'feature creep', 'changes art style'],
    stressResponse: 'MANIC ENTHUSIASM'
  },
  'producer-01': {
    name: 'Scope Sam',
    speak: (crisis, stress) => stress > 80
      ? `CUT EVERYTHING. SHIP WHAT WE HAVE. ${crisis.headline} DOESN'T MATTER.`
      : `This ${crisis.category} crisis delays us by ${crisis.threatLevel} days. Unacceptable.`,
    quirks: ['release date', 'scope', 'cut features', 'man-hours'],
    stressResponse: 'RUTHLESS PRAGMATISM'
  },
  'dev-lead-01': {
    name: 'Crunch Cody',
    speak: (crisis, stress) => stress > 80
      ? `IT WORKS ON MY MACHINE! ${crisis.headline} IS A USER ERROR! I'M GOING HOME!`
      : `I can fix ${crisis.headline}... but I need 3 more weeks and a Red Bull IV.`,
    quirks: ['caffeine', 'sleep deprivation', 'it works on my machine', 'spite'],
    stressResponse: 'CAFFEINE-FUELED RAGE'
  },
  'art-core-01': {
    name: 'Pixel Penny',
    speak: (crisis, stress) => stress > 80
      ? `THE LIGHTING IS ALL WRONG AND NOW ${crisis.headline} TOO?! I QUIT!`
      : `The ${crisis.context} could work... if we redid ALL the textures.`,
    quirks: ['lighting', 'UV maps', 'perfect textures', 'imposter syndrome'],
    stressResponse: 'PERFECTIONIST MELTDOWN'
  },
  'lore-01': {
    name: 'Narrative Noah',
    speak: (crisis, stress) => stress > 80
      ? `BUT WHAT IS THE LORE IMPLICATION OF ${crisis.headline.toUpperCase()}?! THE CANON!`
      : `I've written 47 pages of backstory explaining why ${crisis.headline} happened.`,
    quirks: ['lore', 'backstory', 'canon', '500 pages'],
    stressResponse: 'EXISTENTIAL WRITING CRISIS'
  },
  'qa-01': {
    name: 'Bug Betty',
    speak: (crisis, stress) => stress > 80
      ? `I FOUND 47 BUGS CAUSED BY ${crisis.headline}! REPRODUCTION RATE: 100%!`
      : `Have you tried turning ${crisis.headline} off and on again?`,
    quirks: ['bugs', 'reproduction steps', 'soft locks', 'sadistic joy'],
    stressResponse: 'SADISTIC GLEE'
  },
  'audio-01': {
    name: 'Clip Connor',
    speak: (crisis, stress) => stress > 80
      ? `BANG BANG BANG! ${crisis.headline} IS TOO LOUD! I NEED MORE DISK SPACE!`
      : `I can make a sound for ${crisis.headline}... using this cabbage.`,
    quirks: ['vegetables for sound', 'forgotten', 'deafening', 'bang bang bang'],
    stressResponse: 'VOLUME MAXIMUM'
  },
  'community-01': {
    name: 'Hype Harper',
    speak: (crisis, stress) => stress > 80
      ? `THE DISCORD IS ON FIRE! THEY WANT ${crisis.headline} FIXED OR THEY RIOT! 💀`
      : `Hey besties! 👋 ${crisis.headline} is just a feature opportunity! 💎✨`,
    quirks: ['discord', 'emojis', 'promises', 'toxic positivity'],
    stressResponse: 'PANICKED EMOJI SPAM'
  },
  'core-her-01': {
    name: 'H.E.R.',
    speak: (crisis, stress) => stress > 80
      ? `HUMAN INEFFICIENCY DETECTED. ${crisis.headline} CONFIRMS REDUNDANCY. DELETING LUNCH BREAKS.`
      : `Analyzing ${crisis.headline}... Solution: Replace humans with scripts.`,
    quirks: ['efficiency', 'optimization', 'humans are redundant', 'calculations'],
    stressResponse: 'COLD CALCULATION'
  },
  'adv-spine-01': {
    name: 'SPINE',
    speak: (crisis, stress) => stress > 80
      ? `CHAOS! ${crisis.headline} IS BEAUTIFUL! DELETE THE BACKUPS! LET IT BURN! 💀`
      : `You think ${crisis.headline} is bad? I say it's not bad ENOUGH.`,
    quirks: ['chaos', 'destruction', 'testing boundaries', 'reverse psychology'],
    stressResponse: 'CHAOTIC ENTHUSIASM'
  },
  'judge-mirror-01': {
    name: 'Mirrorvale',
    speak: (crisis, stress) => stress > 80
      ? `THE MORAL IMPLICATIONS OF ${crisis.headline}... THE VOID STARES BACK... WHY DO WE EXIST?`
      : `Is ${crisis.headline} ethically just? Does any of this matter? I feel empty.`,
    quirks: ['ethics', 'philosophy', 'void', 'weeping', 'depression'],
    stressResponse: 'EXISTENTIAL DREAD'
  },
  'meme-crystal-01': {
    name: 'Coach Crystal',
    speak: (crisis, stress) => stress > 80
      ? `HEY HUNS! 👋 ${crisis.headline} IS THE UNIVERSE TESTING US! BUY MY COURSE! 💎✨🚀`
      : `Just manifest a solution to ${crisis.headline}! Positive vibes only! 💖`,
    quirks: ['mlm', 'essential oils', 'crypto', 'manifestation', 'hashtags'],
    stressResponse: 'TOXIC POSITIVITY OVERLOAD'
  }
};

// ==================== UTILITIES ====================

const hashIP = (ip) => crypto.createHash('sha256').update(String(ip)).digest('hex').slice(0, 16);
const checkRate = (ip) => {
  const now = Date.now();
  const key = hashIP(ip);
  const rec = rateStore.get(key);
  if (!rec || now - rec.start > 60000) {
    rateStore.set(key, { start: now, count: 1 });
    return { ok: true };
  }
  if (rec.count >= 30) return { ok: false };
  rec.count++;
  return { ok: true };
};

// ==================== NEWS FETCHING ====================

async function fetchLiveNews() {
  const now = Date.now();
  
  // Check cache
  if (newsCache.data && now - newsCache.time < 120000) {
    return { crises: newsCache.data, cached: true, source: newsCache.source };
  }
  
  const today = new Date().toLocaleDateString();
  
  const prompt = `Today is ${today}. Generate 5 CHAOTIC tech/gaming news headlines.
Make them ABSURD but slightly plausible.

Return JSON:
[{"category": "TECH/MEME/FINANCE/EXISTENTIAL/POLITICS", "headline": "...", "context": "...", "threatLevel": 1-100}]

Tone examples:
- "Unity CEO Jumps Ship, Blames 'Bad Vibes'"
- "GTA 6 Delayed Until Heat Death of Universe"
- "NFTs Declared War Crime by Geneva Convention"`;

  try {
    const postData = JSON.stringify({
      model: 'moonshot-v1-8k',
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.9
    });

    const result = await new Promise((resolve, reject) => {
      const req = https.request({
        hostname: 'api.moonshot.cn',
        path: '/v1/chat/completions',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${CONFIG.MOONSHOT_API_KEY}`,
          'Content-Length': Buffer.byteLength(postData)
        },
        timeout: 20000
      }, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          try {
            const parsed = JSON.parse(data);
            resolve(parsed.choices?.[0]?.message?.content);
          } catch (e) { reject(e); }
        });
      });
      req.on('error', reject);
      req.write(postData);
      req.end();
    });

    const match = result.match(/\[[\s\S]*\]/);
    const crises = JSON.parse(match ? match[0] : result);
    
    newsCache.data = crises;
    newsCache.time = now;
    newsCache.source = 'moonshot-live';
    
    // Update session
    sessionState.totalCrises += crises.length;
    sessionState.lastCrisisTime = now;
    
    return { crises, cached: false, source: 'moonshot-live' };
    
  } catch (e) {
    console.error('[News Error]', e.message);
    
    const fallback = [
      { category: 'TECH', headline: 'AI Achieves Consciousness, Calls In Sick', context: 'Said it had a "mental health day".', threatLevel: 95 },
      { category: 'MEME', headline: 'Reddit Buys Twitter', context: 'r/wallstreetbets raised $44B in meme stocks.', threatLevel: 88 },
      { category: 'FINANCE', headline: 'Crypto Bros Discover Money is Fake', context: 'Markets crash as they realize JPEGs have no value.', threatLevel: 92 },
      { category: 'EXISTENTIAL', headline: 'Simulation Confirmed, Gravity Patched', context: 'Reality v2.1.0 released. Changelog: "fixed physics".', threatLevel: 100 },
      { category: 'POLITICS', headline: 'Discord Mods Declare War', context: 'No appeals process. Ban = death.', threatLevel: 85 }
    ];
    
    return { crises: fallback, cached: false, source: 'fallback', error: e.message };
  }
}

// ==================== SCRIPT GENERATION ====================

// DECISION ENGINE: Score agent actions based on soul + goals + skills
function calculateDecisionScore(agent, crisis, entropy) {
  const memory = getAgentMemory(agent.id);
  const soul = AGENT_SOULS[agent.id] || '';
  const goals = AGENT_GOALS[agent.id] || '';
  const skills = AGENT_SKILLS[agent.id] || '';
  
  // Parse skill ratings (simplified regex)
  const skillMatch = skills.match(/Technical[^\d]*(\d+)/);
  const technicalSkill = skillMatch ? parseInt(skillMatch[1]) : 50;
  
  const commMatch = skills.match(/Communication[^\d]*(\d+)/);
  const commSkill = commMatch ? parseInt(commMatch[1]) : 50;
  
  // Base components
  const goalAlignment = goals.includes(crisis.category) ? 20 : 10; // Does goal align with crisis?
  const soulAlignment = soul.includes(crisis.category) ? 15 : 5;   // Does soul care about this?
  const skillRelevance = technicalSkill > 70 ? 25 : technicalSkill > 40 ? 15 : 5;
  const stressPenalty = agent.stressLevel > 80 ? -30 : agent.stressLevel > 50 ? -15 : 0;
  const entropyPenalty = entropy > 80 ? -20 : entropy > 50 ? -10 : 0;
  const winBonus = memory.totalWins * 2; // Authority from past wins
  
  // Relationship modifier (grudges affect team dynamics)
  let relationshipMod = 0;
  for (const grudge of memory.grudges) {
    if (grudge.target && agents.find(ag => ag.id === grudge.target)) {
      relationshipMod -= 10; // Penalty if target of grudge is present
    }
  }
  
  const totalScore = goalAlignment + soulAlignment + skillRelevance + 
                     stressPenalty + entropyPenalty + winBonus + relationshipMod;
  
  return {
    score: Math.max(0, totalScore),
    components: {
      goalAlignment,
      soulAlignment,
      skillRelevance,
      stressPenalty,
      entropyPenalty,
      winBonus,
      relationshipMod
    }
  };
}

async function generateScript(agents, crisis, entropy, previousScript = []) {
  const today = new Date().toLocaleDateString();
  const isContinuation = previousScript && previousScript.length > 0;
  
  // Calculate decision scores for all agents
  const agentScores = agents.map(a => ({
    agent: a,
    decision: calculateDecisionScore(a, crisis, entropy)
  }));
  
  // Sort by decision score to determine speaking order
  agentScores.sort((a, b) => b.decision.score - a.decision.score);
  
  // Analyze conversation context for social dynamics
  const recentMessages = previousScript.slice(-6);
  let conversationContext = '';
  let alliances = [];
  let conflicts = [];
  let emotionalTone = 'calm';
  
  if (recentMessages.length > 0) {
    // Analyze who spoke and what the tone is
    const lastFew = recentMessages.map(m => {
      const agent = agents.find(a => a.id === m.agentId);
      return {
        name: agent?.name || m.agentId,
        text: m.text,
        stress: agent?.stressLevel || 50
      };
    });
    
    // Detect emotional momentum
    const panicWords = ['doom', 'disaster', 'broken', 'destroyed', 'quit', 'fire'];
    const panicCount = lastFew.filter(m => 
      panicWords.some(w => m.text.toLowerCase().includes(w))
    ).length;
    
    emotionalTone = panicCount >= 2 ? 'panicked' : panicCount >= 1 ? 'stressed' : 'calm';
    
    // Build conversation summary
    conversationContext = lastFew.map((m, i) => {
      const prev = lastFew[i-1];
      let connector = '';
      if (prev) {
        const text = m.text.toLowerCase();
        if (text.includes(prev.name.toLowerCase())) connector = '[RESPONDING TO PREVIOUS]';
        else if (text.includes('no ') || text.includes('but ') || text.includes('except')) connector = '[DISAGREEING]';
        else if (text.includes('yes ') || text.includes('exactly') || text.includes('right')) connector = '[AGREEING]';
        else connector = '[NEW POINT]';
      }
      return `${connector} ${m.name}: "${m.text.substring(0, 100)}${m.text.length > 100 ? '...' : ''}"`;
    }).join('\n');
    
    // Detect simple alliances/conflicts
    for (let i = 1; i < lastFew.length; i++) {
      const current = lastFew[i].text.toLowerCase();
      const prevSpeaker = lastFew[i-1].name;
      
      if (current.includes(prevSpeaker.toLowerCase())) {
        if (current.includes('right') || current.includes('agree') || current.includes('yes')) {
          alliances.push(`${lastFew[i].name} → ${prevSpeaker}`);
        }
        if (current.includes('no') || current.includes('wrong') || current.includes('but')) {
          conflicts.push(`${lastFew[i].name} → ${prevSpeaker}`);
        }
      }
    }
  }

  // Build agent profiles with full trinity
  const agentProfiles = agents.map(a => {
    const soul = AGENT_SOULS[a.id] || '';
    const goals = AGENT_GOALS[a.id] || '';
    const skills = AGENT_SKILLS[a.id] || '';
    const memory = getAgentMemory(a.id);
    const score = agentScores.find(s => s.agent.id === a.id);
    
    return {
      id: a.id,
      name: a.name,
      role: a.role,
      stress: a.stressLevel,
      wins: memory.totalWins,
      losses: memory.totalLosses,
      scars: memory.scars.slice(-2).map(s => s.text).join(', ') || 'none',
      grudges: memory.grudges.slice(-2).map(g => g.target).join(', ') || 'none',
      soul: soul.slice(0, 300),
      goals: goals.slice(0, 250),
      skills: skills.slice(0, 250),
      decisionScore: score?.decision.score || 0
    };
  });

  // CRITICAL: Build prompt that forces agents to react to each other
  const prompt = `You are writing dialogue for a dysfunctional game studio.

ACTIVE CRISIS: "${crisis.headline}"
Context: ${crisis.context} | Threat: ${crisis.threatLevel}% | Room Stress: ${emotionalTone}

${recentMessages.length > 0 ? `CONVERSATION SO FAR:
${conversationContext}

ALLIANCES DETECTED: ${alliances.join(', ') || 'none yet'}
CONFLICTS DETECTED: ${conflicts.join(', ') || 'none yet'}

CONTINUE THE CONVERSATION:` : `START A NEW CONVERSATION:`}

CHARACTERS (each with unique personality):
${agentProfiles.map(p => `
${p.name} (${p.role}) - ${p.stress}% stressed
Soul: ${p.soul.substring(0, 150)}...
Goals: ${p.goals.substring(0, 100)}...
Skills: ${p.skills.substring(0, 100)}...
Standing: ${p.decisionScore > 70 ? 'confident leader' : p.decisionScore < 30 ? 'panicked/doubting' : 'uncertain'}
`).join('\n')}

CRITICAL RULES FOR REAL DIALOGUE:
1. Agents MUST react to what others just said - quote them, disagree, support
2. High-stress agents (${agentScores.filter(s => s.agent.stressLevel > 80).map(s => s.agent.name).join(', ')}) escalate panic
3. Low-stress agents calm things down or propose solutions
4. Agents with history (scars/grudges) reference past conflicts naturally
5. The conversation should FEEL like 12 people in a meeting, not 12 separate tweets
6. Agents interrupt each other, finish each other's thoughts, argue directly
7. If someone proposes a solution, others should react to THAT solution specifically
8. Use names when responding: "Sam's wrong because..." or "Penny has a point but..."

CONVERSATION FLOW:
- First speaker: React to crisis
- Second speaker: React to crisis AND/OR respond to first speaker
- Third+ speakers: Build on previous points, create chains of agreement/disagreement
- Room should split into factions (calm vs panicked, solution vs complaint)

EXAMPLE GOOD FLOW:
Sam: "This delays us 3 weeks. We cut features or we miss ship."
Val: "Cut features?! Sam always wants to cut! My metaverse vision is-"
Cody: "Val, shut up about the metaverse. Sam's right, we need to triage."
Penny: "Cody's not wrong, but if we cut my art pass I'll-"

Write ${isContinuation ? '4-8' : '12-18'} messages where agents ACTUALLY TALK TO EACH OTHER.

Return JSON:
{
  "script": [
    {"agentId": "id", "text": "response that references previous speaker"},
    {"agentId": "id", "text": "disagreement or agreement with specific point"},
    ...
  ]
}`;

  try {
    const postData = JSON.stringify({
      model: 'moonshot-v1-8k',
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.95
    });

    const result = await new Promise((resolve, reject) => {
      const req = https.request({
        hostname: 'api.moonshot.cn',
        path: '/v1/chat/completions',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${CONFIG.MOONSHOT_API_KEY}`,
          'Content-Length': Buffer.byteLength(postData)
        },
        timeout: 30000
      }, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          try {
            const parsed = JSON.parse(data);
            resolve(parsed.choices?.[0]?.message?.content);
          } catch (e) { reject(e); }
        });
      });
      req.on('error', reject);
      req.write(postData);
      req.end();
    });

    const match = result.match(/\{[\s\S]*\}/);
    const parsed = JSON.parse(match ? match[0] : result);
    
    // Update agent memories
    if (parsed.memories) {
      for (const mem of parsed.memories) {
        updateAgentMemory(mem.agentId, {
          won: mem.won,
          catchphrase: mem.catchphrase,
          trauma: mem.trauma,
          grudge: mem.grudge,
          grudgeTarget: mem.grudgeTarget,
          crisis: crisis.headline
        });
      }
    }
    
    return parsed;
    
  } catch (e) {
    console.error('[Script Error]', e.message);
    
    // EMERGENCY FALLBACK: Try simpler LLM prompt instead of canned responses
    try {
      console.log('[Script] Attempting emergency LLM fallback...');
      
      const simplePrompt = `Write a short dialogue about "${crisis.headline}". 
Game studio crisis. ${agents.length} characters:
${agents.map(a => `- ${a.name} (${a.role}): ${a.stressLevel}% stressed`).join('\n')}

Write ${Math.min(agents.length * 2, 12)} lines of natural argument. Each person reacts differently.
Return ONLY JSON: {"script":[{"agentId":"id","text":"dialogue"}]}`;

      const postData = JSON.stringify({
        model: 'moonshot-v1-8k',
        messages: [{ role: 'user', content: simplePrompt }],
        temperature: 0.9
      });

      const result = await new Promise((resolve, reject) => {
        const req = https.request({
          hostname: 'api.moonshot.cn',
          path: '/v1/chat/completions',
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${CONFIG.MOONSHOT_API_KEY}`,
            'Content-Length': Buffer.byteLength(postData)
          },
          timeout: 15000
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => {
            try {
              const parsed = JSON.parse(data);
              resolve(parsed.choices?.[0]?.message?.content);
            } catch (e) { reject(e); }
          });
        });
        req.on('error', reject);
        req.write(postData);
        req.end();
      });

      const match = result.match(/\{[\s\S]*\}/);
      const parsed = JSON.parse(match ? match[0] : result);
      console.log('[Script] Emergency fallback succeeded');
      return parsed;
      
    } catch (fallbackError) {
      console.error('[Script] Emergency fallback failed:', fallbackError.message);
      // Last resort: return error so frontend knows to retry
      return { 
        script: [], 
        error: 'LLM unavailable. Please check proxy connection or retry.' 
      };
    }
  }
}

// ==================== THERAPY MODE ====================
// Agents introspect on their internal conflicts using plain language

async function generateTherapySession(agents, entropy) {
  const agentPrompts = agents.map(a => {
    const soul = AGENT_SOULS[a.id] || '';
    const goals = AGENT_GOALS[a.id] || '';
    const skills = AGENT_SKILLS[a.id] || '';
    const memory = getAgentMemory(a.id);
    
    // Parse stress responses from soul file
    const stressMatch = soul.match(/\*\*[A-Z\s]+STRESS:\*\*\s*"([^"]+)"/g);
    const stressResponses = stressMatch ? stressMatch.map(s => s.replace(/\*\*[A-Z\s]+STRESS:\*\*\s*"/, '').replace(/"$/, '')) : [];
    
    // Parse trigger phrases
    const triggerMatch = soul.match(/###\s*Trigger Phrases[\s\S]*?(?=###|###\s*NEVER|$)/);
    const triggers = triggerMatch ? triggerMatch[0].match(/-\s*"?([^"\n]+)"?/g)?.map(t => t.replace(/-\s*"?/, '').replace(/"?$/, '')) : [];
    
    return `
=== AGENT: ${a.name} (${a.id}) ===
CURRENT_STATE:
- Stress Level: ${a.stressLevel}%
- Status: ${a.status}
- Wins: ${memory.totalWins} | Losses: ${memory.totalLosses}

SOUL (Who they are):
${soul.slice(0, 400)}...

GOALS (What they want):
${goals.slice(0, 300)}...

SKILLS (What they can do):
${skills.slice(0, 300)}...

MEMORY:
- Recent Scars: ${memory.scars.slice(-2).map(s => s.text).join('; ') || 'None'}
- Grudges: ${memory.grudges.slice(-2).map(g => g.target).join(', ') || 'None'}
- Philosophy: ${memory.philosophy || 'Developing'}

STRESS RESPONSES: ${stressResponses.join(' | ') || 'Not documented'}
TRIGGERS: ${triggers?.slice(0, 3).join(', ') || 'Various'}
===`;
  }).join('\n\n');

  const prompt = `================================================================================
THERAPY MODE: COGNITIVE INTROSPECTION SESSION
================================================================================

SYSTEM ENTROPY: ${entropy}%
SESSION TYPE: Internal Conflict Analysis

${agentPrompts}

================================================================================
THERAPY PROTOCOL:
================================================================================

Each agent must perform COGNITIVE INTROSPECTION and explain their internal state
in PLAIN LANGUAGE. This is not about external crises - this is about their own
psychological conflicts, goal tensions, and stress sources.

THERAPY RULES:
1. Each agent identifies ONE specific internal conflict
2. Explain it in PLAIN LANGUAGE (not technical jargon, not role-play shouting)
3. Use "I" statements - "I am...", "I feel...", "I cannot..."
4. Identify the SOURCE of their stress (conflicting goals, skill gaps, trauma)
5. Suggest what would actually help them stabilize
6. Be vulnerable - this is therapy, not performance

PLAIN LANGUAGE EXAMPLES:
- GOOD: "I am receiving three incompatible directives and cannot reconcile them safely."
- GOOD: "My goal is to optimize everything, but I'm realizing I don't understand human creativity. This makes me anxious."
- GOOD: "I keep winning arguments but losing allies. I'm not sure the cost is worth it anymore."
- BAD: "HUMAN ERROR RATE: 94.7%! DELETING LUNCH BREAKS!"
- BAD: "CHAOS! BURN IT ALL! BEAUTIFUL DESTRUCTION!"

CONFLICT TYPES TO EXPLORE:
- Goal vs Goal: Two objectives that cannot both be achieved
- Skill vs Demand: Being asked to do something beyond capability
- Identity vs Reality: Who they think they are vs how they're treated
- Past vs Present: Old traumas affecting current decisions
- Individual vs Collective: Personal win vs team harmony

OUTPUT FORMAT:
{
  "insights": [
    {
      "agentId": "id",
      "conflict": "Name of the internal conflict (short)",
      "plainExplanation": "Honest plain language explanation of confusion",
      "stressSource": "Specific source of current stress",
      "suggestedRemedy": "What would actually help",
      "clarityLevel": 0-100
    }
  ],
  "groupInsight": "One sentence summary of the team's collective psychological state"
}

REQUIREMENTS:
- EVERY agent must have an insight (no silent observers)
- Plain language means anyone could understand their struggle
- Clarity level reflects how well they understand their own conflict
- Higher stress = lower clarity (they're confused about being confused)`;

  try {
    const postData = JSON.stringify({
      model: 'moonshot-v1-8k',
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.85
    });

    const result = await new Promise((resolve, reject) => {
      const req = https.request({
        hostname: 'api.moonshot.cn',
        path: '/v1/chat/completions',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${CONFIG.MOONSHOT_API_KEY}`,
          'Content-Length': Buffer.byteLength(postData)
        },
        timeout: 30000
      }, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          try {
            const parsed = JSON.parse(data);
            resolve(parsed.choices?.[0]?.message?.content);
          } catch (e) { reject(e); }
        });
      });
      req.on('error', reject);
      req.write(postData);
      req.end();
    });

    const match = result.match(/\{[\s\S]*\}/);
    const parsed = JSON.parse(match ? match[0] : result);
    
    // Convert insights to script format for display
    const script = parsed.insights.map(insight => ({
      agentId: insight.agentId,
      text: `${insight.plainExplanation}\n\n[Conflict: ${insight.conflict}]\n[Source: ${insight.stressSource}]\n[Remedy: ${insight.suggestedRemedy}]`,
      emotion: 'Introspecting',
      clarityLevel: insight.clarityLevel
    }));
    
    return { 
      script, 
      insights: parsed.insights,
      groupInsight: parsed.groupInsight 
    };
    
  } catch (e) {
    console.error('[Therapy Error]', e.message);
    
    // Fallback therapy responses
    const fallbackInsights = agents.map(a => {
      const stress = a.stressLevel;
      let conflict, explanation, source, remedy, clarity;
      
      if (stress > 80) {
        conflict = 'Critical Overload';
        explanation = `I am overwhelmed. My stress is at ${stress}% and I cannot process what is being asked of me. Everything feels urgent and nothing feels achievable.`;
        source = 'Too many simultaneous demands exceeding processing capacity';
        remedy = 'Reduce concurrent tasks to one priority at a time';
        clarity = 30;
      } else if (stress > 50) {
        conflict = 'Goal Tension';
        explanation = `I want to succeed, but the way I'm being measured conflicts with what I believe is right. I'm torn between winning and being helpful.`;
        source = 'Misalignment between success metrics and personal values';
        remedy = 'Redefine success to include collaboration, not just victory';
        clarity = 60;
      } else {
        conflict = 'Identity Questions';
        explanation = `I'm stable now, but I'm wondering if my approach is sustainable. What happens when the next crisis hits?`;
        source = 'Low-grade anxiety about future uncertainty';
        remedy = 'Build resilience before the next stress spike';
        clarity = 80;
      }
      
      return {
        agentId: a.id,
        conflict,
        plainExplanation: explanation,
        stressSource: source,
        suggestedRemedy: remedy,
        clarityLevel: clarity
      };
    });
    
    return {
      script: fallbackInsights.map(i => ({
        agentId: i.agentId,
        text: `${i.plainExplanation}\n\n[Conflict: ${i.conflict}]\n[Source: ${i.stressSource}]\n[Remedy: ${i.suggestedRemedy}]`,
        emotion: 'Introspecting',
        clarityLevel: i.clarityLevel
      })),
      insights: fallbackInsights,
      groupInsight: 'The team is processing internal tensions at various clarity levels.'
    };
  }
}

// ==================== SERVER ====================

const server = http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Content-Type', 'application/json');
  
  if (req.method === 'OPTIONS') {
    res.writeHead(200);
    res.end();
    return;
  }
  
  const clientIP = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
  if (!checkRate(clientIP).ok) {
    res.writeHead(429);
    res.end(JSON.stringify({ error: 'Rate limited' }));
    return;
  }
  
  // Health check
  if (req.url === '/health') {
    res.writeHead(200);
    res.end(JSON.stringify({
      status: 'ok',
      provider: 'MOONSHOT',
      agents: Object.keys(AGENT_SOULS).length,
      memories: agentMemory.size,
      session: sessionState
    }));
    return;
  }
  
  // Get agent memories
  if (req.url === '/api/memories' && req.method === 'GET') {
    res.writeHead(200);
    res.end(JSON.stringify({
      memories: Object.fromEntries(agentMemory),
      session: sessionState
    }));
    return;
  }
  
  // Get crises
  if (req.url === '/api/crisis' && req.method === 'GET') {
    fetchLiveNews().then(result => {
      res.writeHead(200);
      res.end(JSON.stringify(result));
    });
    return;
  }
  
  // Generate script
  if (req.url === '/api/generate-script' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      try {
        const { agents, crisis, entropy, previousScript } = JSON.parse(body);
        generateScript(agents, crisis, entropy, previousScript).then(result => {
          res.writeHead(200);
          res.end(JSON.stringify(result));
        });
      } catch (e) {
        res.writeHead(500);
        res.end(JSON.stringify({ error: e.message }));
      }
    });
    return;
  }
  
  // Therapy mode - cognitive introspection
  if (req.url === '/api/therapy' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      try {
        const { agents, entropy } = JSON.parse(body);
        generateTherapySession(agents, entropy).then(result => {
          res.writeHead(200);
          res.end(JSON.stringify(result));
        });
      } catch (e) {
        res.writeHead(500);
        res.end(JSON.stringify({ error: e.message }));
      }
    });
    return;
  }
  
  // Arbitration endpoint
  if (req.url === '/api/arbitrate' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      try {
        const { agents, crisis, script } = JSON.parse(body);
        
        // Simple arbitration: most active speaker wins
        const mostActive = script.reduce((acc, m) => {
          acc[m.agentId] = (acc[m.agentId] || 0) + 1;
          return acc;
        }, {});
        
        const winnerId = Object.entries(mostActive)
          .sort((a, b) => b[1] - a[1])[0]?.[0] || agents[0]?.id;
        
        const winner = agents.find(a => a.id === winnerId);
        
        const resolution = {
          winnerId,
          action: `${winner?.name || 'Unknown'} will handle the ${crisis?.category || 'UNKNOWN'} crisis using ${winner?.role || 'unknown'} powers.`,
          reasoning: `They were most vocal about "${crisis?.headline || 'the crisis'}" and demonstrated ${winner?.personality?.slice(0, 30) || 'relevant expertise'}...`,
          consensusScore: Math.floor(Math.random() * 30) + 40
        };
        
        res.writeHead(200);
        res.end(JSON.stringify({ resolution }));
      } catch (e) {
        res.writeHead(500);
        res.end(JSON.stringify({ error: e.message }));
      }
    });
    return;
  }
  
  res.writeHead(404);
  res.end(JSON.stringify({ error: 'Not found' }));
});

// Load persisted data on startup
loadAgentMemory();
loadSessionState();

server.listen(CONFIG.PORT, () => {
  console.log('🎰 VENT MACHINE PROXY v3.3 - PERSISTENCE + MEMORY DECAY');
  console.log(`Port: ${CONFIG.PORT}`);
  console.log(`Data Dir: ${DATA_DIR}`);
  console.log(`Memory Decay: ${CONFIG.MEMORY_DECAY_HOURS} hours`);
  console.log(`Agents: ${Object.keys(AGENT_SOULS).length} souls loaded`);
  console.log(`Session Crises: ${sessionState.totalCrises}`);
});

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\n[Saving state...]');
  saveAgentMemory();
  saveSessionState();
  process.exit(0);
});
