import React, { useState, useEffect } from 'react';
import { Agent, AGENTS, VentLog, MachineState, CrisisEvent, VentMessage, Resolution, SafeConfig, DEFAULT_SAFE_CONFIG, TherapyInsight } from './types';
import { fetchLiveChaos, generateGroupVentScript, continueGroupVentScript, generateResolution, evolveAgents, archiveEpoch, generateTherapySession } from './services/llmService';
import { PressureGauge } from './components/PressureGauge';
import { TerminalOutput } from './components/TerminalOutput';
import { LeverControl } from './components/LeverControl';
import { SlotMachine } from './components/SlotMachine';
import { VentSessionLog } from './components/VentSessionLog';
import { AddAgentModal } from './components/AddAgentModal';
import { ArbitrationOverlay } from './components/ArbitrationOverlay';
import { SettingsModal } from './components/SettingsModal';
import { ShareButton } from './components/ShareButton';
import { ViewerCount } from './components/ViewerCount';
import { UserCrisisModal } from './components/UserCrisisModal';
import { SocialMemoryGraph } from './components/SocialMemoryGraph';
import { AgentEvolutionPanel } from './components/AgentEvolutionPanel';
import { CulturalMemoryModal } from './components/CulturalMemoryModal';
import { NarrativeFiller } from './components/NarrativeFiller';
import { updateRelationship, deEscalateStress } from './services/llmService';

const safeUUID = () => {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    try { return crypto.randomUUID(); } catch(e) {}
  }
  return Math.random().toString(36).substring(2) + Date.now().toString(36);
};

const App: React.FC = () => {
  const [searchParams] = useState(() => new URLSearchParams(window.location.search));
  const isSpectatorMode = searchParams.get('spectator') === 'true';
  
  const [llmConfig, setLlmConfig] = useState<SafeConfig>(() => {
    if (typeof window === 'undefined') return DEFAULT_SAFE_CONFIG;
    const saved = localStorage.getItem('vm_safe_config');
    return saved ? JSON.parse(saved) : DEFAULT_SAFE_CONFIG;
  });

  const [agents, setAgents] = useState<Agent[]>(() => {
    if (typeof window === 'undefined') return AGENTS.map(a => ({...a, wins: 0, evolution: "Standard Protocol."}));
    const saved = localStorage.getItem('vm_agents_cannon_chaos_v1');
    if (saved) {
      try { 
        const parsed = JSON.parse(saved);
        return parsed.map((a: Agent) => ({ 
          ...a, 
          wins: a.wins ?? 0,
          evolution: a.evolution || "Onboarded."
        }));
      } catch(e) { console.error(e); }
    }
    return AGENTS.map(a => ({...a, wins: 0, evolution: "Onboarded."}));
  });

  const [logs, setLogs] = useState<VentLog[]>(() => {
    if (typeof window === 'undefined') return [];
    const saved = localStorage.getItem('vm_logs');
    return saved ? JSON.parse(saved) : [];
  });

  const [machineState, setMachineState] = useState<MachineState>(() => {
    if (typeof window === 'undefined') return MachineState.IDLE;
    const saved = localStorage.getItem('vm_state');
    if (saved) {
      const parsed = parseInt(saved);
      if ([MachineState.SPINNING, MachineState.FETCHING_CHAOS, MachineState.GENERATING_SCRIPT, MachineState.ARBITRATION, MachineState.THERAPY_MODE].includes(parsed)) {
        return MachineState.IDLE;
      }
      return parsed;
    }
    return MachineState.IDLE;
  });

  const [chaosCandidates, setChaosCandidates] = useState<CrisisEvent[]>(() => {
    if (typeof window === 'undefined') return [];
    const saved = localStorage.getItem('vm_chaos');
    return saved ? JSON.parse(saved) : [];
  });

  const [currentCrisis, setCurrentCrisis] = useState<CrisisEvent | null>(() => {
    if (typeof window === 'undefined') return null;
    const saved = localStorage.getItem('vm_current_crisis');
    return saved ? JSON.parse(saved) : null;
  });

  const [ventScript, setVentScript] = useState<VentMessage[]>(() => {
    if (typeof window === 'undefined') return [];
    const saved = localStorage.getItem('vm_script');
    return saved ? JSON.parse(saved) : [];
  });

  const [cooldown, setCooldown] = useState<number>(() => {
    if (typeof window === 'undefined') return 0;
    const saved = localStorage.getItem('vm_cooldown');
    return saved ? parseInt(saved) : 0;
  });

  const [systemPressure, setSystemPressure] = useState<number>(() => {
    if (typeof window === 'undefined') return 65;
    const saved = localStorage.getItem('vm_pressure');
    return saved ? parseFloat(saved) : 65;
  });

  const [isAutoMode, setIsAutoMode] = useState<boolean>(false);
  const [lastResolution, setLastResolution] = useState<Resolution | null>(null);
  const [activeSpeaker, setActiveSpeaker] = useState<{id: string, emotion: string} | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isUserCrisisModalOpen, setIsUserCrisisModalOpen] = useState(false);
  const [isArchiving, setIsArchiving] = useState(false);
  const [isTherapyMode, setIsTherapyMode] = useState(false);
  const [therapyInsights, setTherapyInsights] = useState<TherapyInsight[]>([]);
  const [groupTherapyInsight, setGroupTherapyInsight] = useState<string>('');
  const [isCulturalMemoryOpen, setIsCulturalMemoryOpen] = useState(false);
  const [activePanel, setActivePanel] = useState<'agents' | 'social' | 'evolution'>('agents');

  useEffect(() => { localStorage.setItem('vm_safe_config', JSON.stringify(llmConfig)); }, [llmConfig]);
  useEffect(() => { localStorage.setItem('vm_agents_cannon_chaos_v1', JSON.stringify(agents)); }, [agents]);
  useEffect(() => { localStorage.setItem('vm_logs', JSON.stringify(logs)); }, [logs]);
  useEffect(() => { localStorage.setItem('vm_state', machineState.toString()); }, [machineState]);
  useEffect(() => { localStorage.setItem('vm_chaos', JSON.stringify(chaosCandidates)); }, [chaosCandidates]);
  useEffect(() => { localStorage.setItem('vm_current_crisis', JSON.stringify(currentCrisis)); }, [currentCrisis]);
  useEffect(() => { localStorage.setItem('vm_script', JSON.stringify(ventScript)); }, [ventScript]);
  useEffect(() => { localStorage.setItem('vm_cooldown', cooldown.toString()); }, [cooldown]);
  useEffect(() => { localStorage.setItem('vm_pressure', systemPressure.toString()); }, [systemPressure]);

  useEffect(() => {
    const loadChaos = async () => {
      if (chaosCandidates.length < 2) {
        const chaos = await fetchLiveChaos();
        setChaosCandidates(prev => [...prev, ...chaos]);
      }
    };
    loadChaos();
  }, []);

  useEffect(() => {
    const entropyInterval = setInterval(() => {
      setSystemPressure(prev => {
        const growthRate = prev > 80 ? 0.8 : 0.2;
        return Math.min(prev + growthRate, 99);
      });
    }, 4000);
    return () => clearInterval(entropyInterval);
  }, []);

  useEffect(() => {
    if (cooldown > 0) {
      const timer = setInterval(() => {
        setCooldown(c => Math.max(c - 1, 0));
      }, 1000);
      return () => clearInterval(timer);
    } else if (machineState === MachineState.COOLDOWN) {
      if (isAutoMode) {
        initiateCrisisLoop();
      } else {
        setMachineState(MachineState.IDLE);
      }
    }
  }, [cooldown, machineState, isAutoMode]);

  const initiateCrisisLoop = async () => {
    setMachineState(MachineState.FETCHING_CHAOS);
    if (chaosCandidates.length <= 2) {
      const newChaos = await fetchLiveChaos();
      setChaosCandidates(prev => [...prev, ...newChaos]);
    }
    // Start spinning - SlotMachine will call handleSlotLand when it stops
    setMachineState(MachineState.SPINNING);
    // The SlotMachine component will auto-stop after ~2.5s and call onLand
    // handleSlotLand then sets state to PLAYING_SESSION after generating script
  };

  const handleToggleAuto = (enabled: boolean) => {
    setIsAutoMode(enabled);
    if (enabled && machineState === MachineState.IDLE) {
      initiateCrisisLoop();
    }
  };

  const handleArchiveEpoch = async () => {
    if (logs.length > 5 && !isArchiving) {
      setIsArchiving(true);
      try {
        const archiveLog = await archiveEpoch(logs);
        setLogs([archiveLog]);
        setSystemPressure(25);
        // DE-ESCALATION: Archiving reduces stress and improves relationships
        deEscalateStress(agents.map(a => a.id), 'archive crisis history');
      } catch(e) {
        console.error(e);
      } finally {
        setIsArchiving(false);
      }
    }
  };

  // THERAPY MODE: Trigger cognitive introspection session
  const handleStartTherapy = async () => {
    if (machineState !== MachineState.IDLE && machineState !== MachineState.COOLDOWN) return;
    
    setMachineState(MachineState.THERAPY_MODE);
    setIsTherapyMode(true);
    setVentScript([]);
    setCurrentCrisis(null);
    
    try {
      const { script, insights, groupInsight } = await generateTherapySession(agents, systemPressure);
      setVentScript(script);
      setTherapyInsights(insights);
      setGroupTherapyInsight(groupInsight);
      
      // Log therapy session start
      setLogs(prev => [...prev, {
        id: safeUUID(),
        agentId: 'THERAPIST',
        timestamp: new Date().toISOString(),
        conflictType: 'EMOTIONAL_OVERLOAD',
        priority: 'MEDIUM',
        rawOutput: `THERAPY MODE INITIATED\nGroup Insight: ${groupInsight}\nAgents: ${agents.length} participating`,
        pressureRelease: 0
      }]);
      
      // After therapy session completes, reduce stress (catharsis)
      const sessionDuration = script.length * 3000 + 2000;
      setTimeout(() => {
        // Apply catharsis - stress reduction from expressing internal conflicts
        setAgents(prevAgents => prevAgents.map(agent => {
          const insight = insights.find((i: TherapyInsight) => i.agentId === agent.id);
          const clarityBonus = insight ? insight.clarityLevel / 5 : 10; // Higher clarity = more stress relief
          const newStress = Math.max(agent.stressLevel - clarityBonus - 5, 0);
          return {
            ...agent,
            stressLevel: newStress,
            status: newStress < 30 ? 'STABLE' : newStress < 60 ? 'CONFLICT' : 'CRITICAL',
            evolution: `Therapy helped. Clarity: ${Math.round(insight?.clarityLevel || 50)}%.`
          };
        }));
        
        setSystemPressure(p => Math.max(p - 15, 10));
        setIsTherapyMode(false);
        setMachineState(MachineState.COOLDOWN);
        setCooldown(8);
        
        setLogs(prev => [...prev, {
          id: safeUUID(),
          agentId: 'THERAPIST',
          timestamp: new Date().toISOString(),
          conflictType: 'SYSTEM_COMPRESSION',
          priority: 'LOW',
          rawOutput: `THERAPY COMPLETE\nCatharsis achieved. Stress reduced across all agents.\nGroup Clarity: ${Math.round(insights.reduce((a: number, i: TherapyInsight) => a + i.clarityLevel, 0) / insights.length)}%`,
          pressureRelease: 15
        }]);
      }, sessionDuration);
      
    } catch (e) {
      console.error('[Therapy] Session failed:', e);
      setIsTherapyMode(false);
      setMachineState(MachineState.IDLE);
    }
  };

  // USER CRISIS INPUT: Handle custom crisis injection
  const handleUserCrisis = (crisis: CrisisEvent) => {
    setChaosCandidates(prev => [crisis, ...prev]);
    setLogs(prev => [...prev, {
      id: safeUUID(),
      agentId: 'USER',
      timestamp: new Date().toISOString(),
      conflictType: 'USER_INJECTED_CRISIS',
      priority: crisis.threatLevel > 80 ? 'CRITICAL' : 'HIGH',
      rawOutput: `USER INJECTED CRISIS: ${crisis.headline} [${crisis.category}]\nContext: ${crisis.context}\nThreat: ${crisis.threatLevel}%`,
      pressureRelease: 0
    }]);
    // Auto-start the crisis if idle
    if (machineState === MachineState.IDLE) {
      initiateCrisisLoop();
    }
  };

  const applyStressToAgents = (script: VentMessage[]) => {
    setAgents(prevAgents => {
      console.log(`[Stress] Applying stress from ${script.length} messages to ${prevAgents.length} agents`);
      return prevAgents.map(agent => {
        const messageCount = script.filter(m => m.agentId === agent.id).length;
        if (messageCount === 0) return agent;
        const stressIncrease = messageCount * 4;
        const newStress = Math.min(agent.stressLevel + stressIncrease, 100);
        let newStatus = agent.status;
        if (newStress > 90) newStatus = 'CRITICAL';
        else if (newStress > 60) newStatus = 'CONFLICT';
        else newStatus = 'STABLE';
        console.log(`[Stress] ${agent.name}: ${agent.stressLevel}% -> ${newStress}% (${messageCount} messages)`);
        return { ...agent, stressLevel: newStress, status: newStatus };
      });
    });
  };

  const handleLeverPull = async () => {
    if (machineState !== MachineState.IDLE || cooldown > 0) return;
    initiateCrisisLoop();
  };

  const executeArbitration = async (script: VentMessage[], crisis: CrisisEvent) => {
    try {
      const res = await generateResolution(agents, crisis, script);
      setLastResolution(res);
      return res;
    } catch (e) {
      console.error(e);
      return null;
    }
  };

  const handleSlotLand = async (event: CrisisEvent) => {
    console.log(`[Crisis] Slot landed on: "${event.headline}" [${event.category}, ${event.threatLevel}% threat]`);
    setVentScript([]);
    setCurrentCrisis(event);
    setLastResolution(null);
    setChaosCandidates(prev => prev.filter(c => c !== event));

    const script = await generateGroupVentScript(agents, event, systemPressure);
    setVentScript(script);
    applyStressToAgents(script);
    setMachineState(MachineState.PLAYING_SESSION);

    setLogs(prev => [...prev, {
      id: safeUUID(),
      agentId: 'SYSTEM',
      timestamp: new Date().toISOString(),
      conflictType: 'GROUP_CRISIS',
      priority: event.threatLevel > 80 ? 'CRITICAL' : 'HIGH',
      rawOutput: `CRISIS: ${event.headline} [${event.category}]\nContext: ${event.context}\nEntropy: ${Math.round(systemPressure)}%`,
      pressureRelease: 0
    }]);

    const arbitrationPromise = executeArbitration(script, event);
    const scriptDuration = (script.length * 2500) + 2000;
    
    setTimeout(() => {
      setMachineState(MachineState.ARBITRATION);
    }, scriptDuration);

    setTimeout(async () => {
      const res = await arbitrationPromise;
      if (res) {
        setLogs(prev => [...prev, {
          id: safeUUID(),
          agentId: 'ARBITER',
          timestamp: new Date().toISOString(),
          conflictType: 'ARBITRATION_RULING',
          priority: 'MEDIUM',
          rawOutput: `WINNER: ${res.winnerId}\nAction: ${res.action}\nReasoning: ${res.reasoning}`,
          pressureRelease: 20
        }]);

        const evolvedAgents = await evolveAgents(agents, res, event);
        const winner = evolvedAgents.find(a => a.id === res.winnerId);
        console.log(`[Evolution] Winner: ${winner?.name}, Agents evolved: ${evolvedAgents.length}`);
        setAgents(evolvedAgents.map(a => 
          a.id === res.winnerId ? { ...a, wins: (a.wins || 0) + 1 } : a
        ));
        
        // RELATIONSHIP MEMORY: Update relationships based on arbitration
        agents.forEach(agent => {
          if (agent.id === res.winnerId) {
            // Winner gains reputation with everyone
            agents.forEach(other => {
              if (other.id !== agent.id) {
                updateRelationship(other.id, agent.id, 15, `Won arbitration for "${event.headline}"`);
              }
            });
          } else {
            // Losers may resent winner
            if (Math.random() > 0.5) {
              updateRelationship(agent.id, res.winnerId, -10, `Lost arbitration to them on "${event.headline}"`);
            }
          }
        });
      }

      setTimeout(() => {
        const releaseAmount = systemPressure > 80 ? 15 : 30;
        setSystemPressure(p => Math.max(p - releaseAmount, 10));
        setCooldown(isAutoMode ? 8 : 10);
        setMachineState(MachineState.COOLDOWN);
      }, 6000);
    }, scriptDuration + 1000);
  };

  const handleContinue = async () => {
    if (!currentCrisis) return;
    if (machineState !== MachineState.IDLE && machineState !== MachineState.COOLDOWN) return;
    
    setMachineState(MachineState.GENERATING_SCRIPT);

    const newMessages = await continueGroupVentScript(agents, currentCrisis, ventScript, systemPressure);
    
    if (newMessages.length > 0) {
      setVentScript(prev => [...prev, ...newMessages]);
      applyStressToAgents(newMessages);
      setMachineState(MachineState.PLAYING_SESSION);
      setLastResolution(null);
      
      setLogs(prev => [...prev, {
        id: safeUUID(),
        agentId: 'SYSTEM',
        timestamp: new Date().toISOString(),
        conflictType: 'EMOTIONAL_OVERLOAD',
        priority: 'MEDIUM',
        rawOutput: `SESSION EXTENDED. AGENT STRESS RISING.`,
        pressureRelease: 5
      }]);

      const fullScript = [...ventScript, ...newMessages];
      const arbitrationPromise = executeArbitration(fullScript, currentCrisis);
      const duration = (newMessages.length * 2500) + 1000;

      setTimeout(() => {
        setMachineState(MachineState.ARBITRATION);
      }, duration);

      setTimeout(async () => {
        const res = await arbitrationPromise;
        if (res) {
          const evolvedAgents = await evolveAgents(agents, res, currentCrisis);
          setAgents(evolvedAgents.map(a => 
            a.id === res.winnerId ? { ...a, wins: (a.wins || 0) + 1 } : a
          ));
          setLogs(prev => [...prev, {
            id: safeUUID(),
            agentId: 'ARBITER',
            timestamp: new Date().toISOString(),
            conflictType: 'ARBITRATION_RULING',
            priority: 'MEDIUM',
            rawOutput: `FINAL: ${res.winnerId} wins. ${res.action}`,
            pressureRelease: 15
          }]);
        }
        setTimeout(() => {
          setSystemPressure(p => Math.max(p - 10, 10));
          setMachineState(MachineState.COOLDOWN);
        }, 5000);
      }, duration + 1000);
    } else {
      setMachineState(MachineState.IDLE);
    }
  };

  // Check if we can continue - allow when in IDLE or COOLDOWN with existing crisis
  const canContinue = !!currentCrisis && ventScript.length > 0 && 
    (machineState === MachineState.IDLE || machineState === MachineState.COOLDOWN);

  // Check if lever is disabled
  const isLeverDisabled = machineState !== MachineState.IDLE && machineState !== MachineState.COOLDOWN;

  return (
    <div className="h-screen w-screen bg-[#050505] text-[#e0e0e0] flex flex-col overflow-hidden">
      
      <AddAgentModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onAdd={(a) => setAgents(p => [...p, a])} />
      <SettingsModal isOpen={isSettingsModalOpen} onClose={() => setIsSettingsModalOpen(false)} config={llmConfig} onSave={setLlmConfig} />
      <UserCrisisModal isOpen={isUserCrisisModalOpen} onClose={() => setIsUserCrisisModalOpen(false)} onSubmit={handleUserCrisis} />
      <CulturalMemoryModal isOpen={isCulturalMemoryOpen} onClose={() => setIsCulturalMemoryOpen(false)} logs={logs} agents={agents} />

      {/* Header - Fixed height */}
      <header className="h-14 border-b border-gray-800 flex items-center justify-between px-4 shrink-0 bg-[#080808]">
        <div className="flex flex-col">
          <h1 className="text-lg font-bold tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-gray-200 to-gray-500">
            VENT_MACHINE<span className="text-[10px] align-top text-red-500">v4</span>
          </h1>
          <p className="text-[9px] text-gray-500 uppercase tracking-wider">Chaos Protocol: Soul + Goals + Skills</p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={handleStartTherapy}
            disabled={machineState !== MachineState.IDLE && machineState !== MachineState.COOLDOWN}
            className={`px-3 py-1.5 border rounded text-[10px] font-bold uppercase tracking-wider transition-all ${
              isTherapyMode 
                ? 'bg-purple-900/50 border-purple-500 text-purple-400 animate-pulse' 
                : 'bg-purple-900/20 border-purple-700 text-purple-400 hover:bg-purple-900/40 disabled:opacity-30 disabled:cursor-not-allowed'
            }`}
          >
            {isTherapyMode ? '● Therapy Active' : '♥ Therapy Mode'}
          </button>
          <button 
            onClick={() => setIsUserCrisisModalOpen(true)}
            className="px-3 py-1.5 bg-red-900/50 border border-red-700 rounded text-[10px] text-red-400 hover:bg-red-900/70 font-bold uppercase tracking-wider"
          >
            + Inject Crisis
          </button>
          <ViewerCount isSpectatorMode={isSpectatorMode} />
          <PressureGauge value={systemPressure} label="Burnout" />
          {currentCrisis && <ShareButton crisisId={currentCrisis.category} entropy={systemPressure} winner={lastResolution?.winnerId} />}
          <button 
            onClick={() => setIsCulturalMemoryOpen(true)}
            className="px-3 py-1.5 bg-amber-900/30 border border-amber-700 rounded text-[10px] text-amber-400 hover:bg-amber-900/50 font-bold uppercase tracking-wider"
            title="View Cultural Memory Archive"
          >
            📜 History
          </button>
          <button onClick={() => setIsSettingsModalOpen(true)} className="p-1.5 border border-gray-700 rounded hover:bg-gray-800">
            <span className="text-sm">⚙</span>
          </button>
        </div>
      </header>

      {/* Main Content - Fixed layout */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* Left Panel - Tabbed: Agents / Social Graph / Evolution */}
        <div className="w-72 border-r border-gray-800 flex flex-col hidden lg:flex bg-[#080808]">
          {/* Tab Navigation */}
          <div className="h-7 border-b border-gray-800 flex items-center shrink-0">
            <button 
              onClick={() => setActivePanel('agents')}
              className={`flex-1 h-full text-[10px] font-bold uppercase tracking-wider transition-colors ${activePanel === 'agents' ? 'text-cyan-400 bg-cyan-900/20 border-b-2 border-cyan-500' : 'text-gray-500 hover:text-gray-400'}`}
            >
              Agents
            </button>
            <button 
              onClick={() => setActivePanel('social')}
              className={`flex-1 h-full text-[10px] font-bold uppercase tracking-wider transition-colors ${activePanel === 'social' ? 'text-green-400 bg-green-900/20 border-b-2 border-green-500' : 'text-gray-500 hover:text-gray-400'}`}
            >
              Social
            </button>
            <button 
              onClick={() => setActivePanel('evolution')}
              className={`flex-1 h-full text-[10px] font-bold uppercase tracking-wider transition-colors ${activePanel === 'evolution' ? 'text-purple-400 bg-purple-900/20 border-b-2 border-purple-500' : 'text-gray-500 hover:text-gray-400'}`}
            >
              Evolution
            </button>
          </div>
          
          {/* Panel Content */}
          <div className="flex-1 overflow-hidden">
            {activePanel === 'agents' && (
              <div className="h-full flex flex-col">
                <div className="flex-1 overflow-y-auto p-2 space-y-2">
                  {agents.map(agent => (
                    <div key={agent.id} className={`p-2 border rounded text-xs transition-colors ${activeSpeaker?.id === agent.id ? 'border-cyan-500 bg-cyan-900/20' : 'border-gray-800 bg-black/40 hover:border-gray-700'}`}>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm">{agent.icon}</span>
                        <span className={`font-bold text-[11px] ${agent.avatarColor}`}>{agent.name}</span>
                        <span className={`ml-auto text-[8px] px-1 rounded ${agent.status === 'CRITICAL' ? 'bg-red-900 text-red-400' : agent.status === 'CONFLICT' ? 'bg-yellow-900 text-yellow-400' : 'bg-gray-800 text-gray-400'}`}>{agent.status}</span>
                      </div>
                      <div className="text-[9px] text-gray-500 truncate leading-tight">{agent.evolution || 'Stable'}</div>
                      <div className="mt-1.5 h-1 bg-gray-800 rounded-full overflow-hidden">
                        <div className={`h-full transition-all ${agent.stressLevel > 80 ? 'bg-red-500' : agent.stressLevel > 50 ? 'bg-yellow-500' : 'bg-green-600'}`} style={{width: `${agent.stressLevel}%`}} />
                      </div>
                    </div>
                  ))}
                </div>
                <div className="h-6 border-t border-gray-800 flex items-center justify-between px-3 shrink-0 bg-black/40">
                  <span className="text-[9px] text-gray-600">{agents.length} agents active</span>
                  <button onClick={() => setIsModalOpen(true)} className="text-[10px] text-cyan-500 hover:text-cyan-400 font-bold">+ Add</button>
                </div>
              </div>
            )}
            
            {activePanel === 'social' && (
              <SocialMemoryGraph agents={agents} activeSpeaker={activeSpeaker} />
            )}
            
            {activePanel === 'evolution' && (
              <AgentEvolutionPanel agents={agents} />
            )}
          </div>
        </div>

        {/* Center Panel - Chat & Controls */}
        <div className="flex-1 flex flex-col min-w-0 bg-[#050505]">
          
          {/* Slot Machine - Compact */}
          <div className="h-20 shrink-0 p-2">
            <SlotMachine candidates={chaosCandidates} spinning={machineState === MachineState.SPINNING} onLand={handleSlotLand} />
          </div>

          {/* Chat Container */}
          <div className="flex-1 border-x border-gray-800 mx-2 mb-2 relative bg-black/50 rounded overflow-hidden flex flex-col">
            {/* Crisis Header */}
            <div className="bg-gray-900 border-b border-gray-800">
              {/* Active Crisis Display or Therapy Mode */}
              {isTherapyMode ? (
                <div className="px-3 py-2 border-b border-gray-800 bg-purple-900/10">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-purple-900 text-purple-400">
                      THERAPY
                    </span>
                    <span className="text-[10px] text-purple-400/70">{agents.length} AGENTS INTROSPECTING</span>
                    <span className="text-[9px] text-purple-500 animate-pulse font-bold ml-auto">♥ ACTIVE</span>
                  </div>
                  <h3 className="text-sm font-bold text-white leading-tight">Cognitive Introspection Session</h3>
                  <p className="text-[10px] text-purple-400/60 mt-0.5 line-clamp-1">
                    {groupTherapyInsight || 'Agents analyzing internal conflicts in plain language...'}
                  </p>
                </div>
              ) : currentCrisis ? (
                <div className="px-3 py-2 border-b border-gray-800">
                  <div className="flex items-center gap-2 mb-1">
                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${currentCrisis.threatLevel > 80 ? 'bg-red-900 text-red-400' : currentCrisis.threatLevel > 50 ? 'bg-yellow-900 text-yellow-400' : 'bg-blue-900 text-blue-400'}`}>
                      {currentCrisis.category}
                    </span>
                    <span className="text-[10px] text-gray-500">THREAT: {currentCrisis.threatLevel}%</span>
                    {isAutoMode && <span className="text-[9px] text-red-500 animate-pulse font-bold ml-auto">AUTO</span>}
                  </div>
                  <h3 className="text-sm font-bold text-white leading-tight">{currentCrisis.headline}</h3>
                  <p className="text-[10px] text-gray-500 mt-0.5 line-clamp-1">{currentCrisis.context}</p>
                </div>
              ) : (
                <div className="h-8 flex items-center px-3">
                  <span className="text-[10px] text-gray-600 font-mono">#{machineState === MachineState.SPINNING ? 'SELECTING CRISIS...' : 'IDLE - PULL LEVER'}</span>
                </div>
              )}
              {/* Status Bar */}
              <div className="h-6 flex items-center px-3 justify-between shrink-0">
                <span className="text-[10px] text-gray-500 font-mono">
                  {machineState === MachineState.THERAPY_MODE ? '>> COGNITIVE INTROSPECTION...' :
                   machineState === MachineState.PLAYING_SESSION ? '>> DELIBERATING...' : 
                   machineState === MachineState.GENERATING_SCRIPT ? '>> GENERATING RESPONSES...' :
                   machineState === MachineState.ARBITRATION ? '>> ARBITRATING...' :
                   machineState === MachineState.COOLDOWN ? '>> COOLDOWN' : '>> WAITING'}
                </span>
                <span className={`w-1.5 h-1.5 rounded-full ${
                  machineState === MachineState.THERAPY_MODE ? 'bg-purple-500 animate-pulse' :
                  machineState === MachineState.PLAYING_SESSION ? 'bg-green-500 animate-pulse' : 
                  machineState === MachineState.GENERATING_SCRIPT ? 'bg-yellow-500 animate-pulse' : 
                  machineState === MachineState.ARBITRATION ? 'bg-cyan-500 animate-pulse' : 'bg-gray-700'
                }`} />
              </div>
            </div>

            {/* Messages Area */}
            <div className="flex-1 relative overflow-hidden">
              {machineState === MachineState.IDLE && !currentCrisis && !isTherapyMode && (
                <NarrativeFiller agents={agents} systemPressure={systemPressure} />
              )}
              {(machineState === MachineState.FETCHING_CHAOS || machineState === MachineState.GENERATING_SCRIPT) && (
                <div className="absolute inset-0 flex items-center justify-center text-yellow-600 text-xs animate-pulse">
                  SYNCHRONIZING...
                </div>
              )}
              {machineState === MachineState.ARBITRATION && (
                <ArbitrationOverlay resolution={lastResolution} agents={agents} />
              )}
              <VentSessionLog 
                messages={ventScript} 
                agents={agents} 
                isPlaying={machineState === MachineState.PLAYING_SESSION || machineState === MachineState.THERAPY_MODE}
                isTherapyMode={isTherapyMode}
                onSpeakerChange={(id, emotion) => setActiveSpeaker(id && emotion ? {id, emotion} : null)}
              />
            </div>
          </div>

          {/* Controls - Fixed height */}
          <div className="h-16 shrink-0 px-2 pb-2">
            <LeverControl 
              label={machineState === MachineState.IDLE ? "PULL" : "..."}
              onClick={handleLeverPull}
              onContinue={handleContinue}
              disabled={isLeverDisabled}
              canContinue={canContinue}
              cooldown={cooldown}
              isAutoMode={isAutoMode}
              onToggleAuto={handleToggleAuto}
            />
          </div>
        </div>

        {/* Right Panel - Logs */}
        <div className="w-72 border-l border-gray-800 flex flex-col hidden lg:flex bg-[#080808]">
          <div className="h-7 border-b border-gray-800 flex items-center px-3 shrink-0">
            <span className="text-[10px] text-gray-500 uppercase font-bold">/var/logs</span>
          </div>
          <div className="flex-1 overflow-hidden">
            <TerminalOutput logs={logs} agents={agents} onCompress={handleArchiveEpoch} isCompressing={isArchiving} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
