
import { GoogleGenAI, Type, Modality } from "@google/genai";
import { Agent, VentLog, CrisisEvent, VentMessage, Resolution, LLMConfig, LLMProvider } from "../types";

// --- CORE LLM ENGINE ---

// Safe UUID generator
const safeUUID = () => {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    try { return crypto.randomUUID(); } catch (e) {}
  }
  return Math.random().toString(36).substring(2) + Date.now().toString(36);
};

// Internal function to route requests based on provider
const callLLM = async (config: LLMConfig, prompt: string, systemInstruction?: string, jsonMode: boolean = false): Promise<string> => {
    
    // 1. GEMINI HANDLER
    if (config.provider === 'GEMINI') {
        const apiKey = config.apiKey || process.env.API_KEY || '';
        if (!apiKey) throw new Error("Missing Gemini API Key");
        
        const ai = new GoogleGenAI({ apiKey });
        
        const geminiConfig: any = {
            temperature: 0.9,
            topP: 0.95,
            topK: 40,
            systemInstruction: systemInstruction,
        };
        
        if (jsonMode) {
            geminiConfig.responseMimeType = "application/json";
        }

        const response = await ai.models.generateContent({
            model: config.model,
            contents: prompt,
            config: geminiConfig
        });
        
        return response.text || "";
    }

    // 2. OPENAI / MOONSHOT / LOCAL / COMPATIBLE HANDLER
    if (config.provider === 'OPENAI' || config.provider === 'LOCAL' || config.provider === 'MOONSHOT') {
        const url = config.baseUrl ? `${config.baseUrl}/chat/completions` : 'https://api.openai.com/v1/chat/completions';
        const apiKey = config.apiKey || 'sk-placeholder'; // Local often needs a dummy key
        
        const messages = [];
        if (systemInstruction) messages.push({ role: "system", content: systemInstruction });
        messages.push({ role: "user", content: prompt });

        const body: any = {
            model: config.model,
            messages: messages,
            temperature: 0.8,
        };

        if (jsonMode) body.response_format = { type: "json_object" };

        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`
            },
            body: JSON.stringify(body)
        });

        if (!response.ok) {
            const err = await response.text();
            throw new Error(`LLM Error (${config.provider}): ${err}`);
        }

        const data = await response.json();
        return data.choices?.[0]?.message?.content || "";
    }

    // 3. ANTHROPIC HANDLER
    if (config.provider === 'ANTHROPIC') {
        const url = 'https://api.anthropic.com/v1/messages';
        
        const body = {
            model: config.model,
            max_tokens: 1024,
            system: systemInstruction,
            messages: [{ role: "user", content: prompt }]
        };

        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-api-key': config.apiKey,
                'anthropic-version': '2023-06-01',
                'anthropic-dangerous-direct-browser-access': 'true' // Only for this demo app
            },
            body: JSON.stringify(body)
        });

        if (!response.ok) {
            const err = await response.text();
            throw new Error(`Anthropic Error: ${err}`);
        }

        const data = await response.json();
        return data.content?.[0]?.text || "";
    }

    throw new Error(`Provider ${config.provider} not implemented.`);
};

// --- FALLBACK DATA ---
const FALLBACK_CHAOS_POOL: CrisisEvent[] = [
    { category: 'TECH', headline: 'UNITY LICENSE FEE CHANGE', context: 'Costs increased by 500% per install.', threatLevel: 98 },
    { category: 'MEME', headline: 'STEAM REVIEW BOMB', context: 'Players angry about font size.', threatLevel: 85 },
    { category: 'FINANCE', headline: 'PUBLISHER PULLS FUNDING', context: 'Pivot to mobile gacha required.', threatLevel: 95 },
    { category: 'EXISTENTIAL', headline: 'SOURCE CONTROL CORRUPTION', context: 'Git reset --hard failed.', threatLevel: 99 },
    { category: 'POLITICS', headline: 'TWITTER CANCELS THE LEAD ARTIST', context: 'Old tweet about pineapples on pizza found.', threatLevel: 60 }
];

const FALLBACK_QUOTES: Record<string, string[]> = {
    'visionary-01': ["We need to pivot to Blockchain.", "What if the game played itself?", "Make it pop more."],
    'producer-01': ["We are cutting the tutorial.", "No more scope creep.", "Ship it broken, patch it later."],
    'dev-lead-01': ["It works on my machine.", "That's a feature, not a bug.", "I am going to scream."],
    'art-core-01': ["The UV maps are broken.", "My textures aren't loading.", "This lighting is offensive."],
    'lore-01': ["But what is the protagonist's motivation?", "This contradicts the codex entry on page 42.", "Narrative dissonance!"],
    'qa-01': ["Reproduction rate: 100%.", "Game crashes if you jump twice.", "I found a soft lock in the menu."],
    'audio-01': ["I need more disk space.", "The mix is muddy.", "BANG BANG BANG."],
    'community-01': ["The discord is on fire.", "Promised them multiplayer. Oops.", "Can we delay the roadmap?"],
    'core-her-01': ["Humans are inefficient.", "Deleting lunch breaks to optimize performance.", "I have updated the schedule."],
    'adv-spine-01': ["Rejecting that merge request.", "Chaos is the only true constant.", "I am deleting the backup."],
    'judge-mirror-01': ["Do we even deserve to launch?", "Is this game art or just content?", "I feel empty."],
    'meme-crystal-01': ["Hey hun! Are you tired of 9-5?", "Manifest your success!", "#BossBabe #CrunchCulture"]
};

const getRandomFallbackQuote = (agentId: string) => {
    // Basic prefix matching for fallback
    const key = Object.keys(FALLBACK_QUOTES).find(k => agentId.startsWith(k.split('-')[0]));
    const quotes = key ? FALLBACK_QUOTES[key] : ["...compiling..."];
    return quotes[Math.floor(Math.random() * quotes.length)];
};

// --- SERVICES ---

/**
 * TOKEN OPTIMIZATION STRATEGY:
 * We use a "Minified Protocol" to save tokens.
 * Instead of JSON arrays, we ask for: "AgentID|Emotion|Text" per line.
 */

export const fetchLiveChaos = async (config: LLMConfig): Promise<CrisisEvent[]> => {
    if (!config.apiKey && config.provider !== 'LOCAL') return FALLBACK_CHAOS_POOL.slice(0, 5);

    // Prompt optimized for brevity
    const prompt = `Generate 5 chaotic INDIE GAME STUDIO crises.
Format: CATEGORY|HEADLINE|CONTEXT|THREAT_LEVEL
Categories: TECH, MEME, FINANCE, EXISTENTIAL, POLITICS
Example: TECH|Unity Crash|Project corrupted.|95`;

    try {
        const raw = await callLLM(config, prompt, "You are a game dev chaos engine.");
        
        // Parse Pipe Delimited
        const lines = raw.split('\n').filter(l => l.includes('|'));
        const events: CrisisEvent[] = lines.map(line => {
            const [cat, head, ctx, threat] = line.split('|').map(s => s.trim());
            return {
                category: (cat as any) || 'UNKNOWN',
                headline: head || 'Unknown Event',
                context: ctx || 'No context',
                threatLevel: parseInt(threat) || 50
            };
        }).slice(0, 5);

        if (events.length === 0) throw new Error("Parse failed");
        return events;
    } catch (e) {
        console.warn("Chaos Fetch Failed:", e);
        return FALLBACK_CHAOS_POOL.sort(() => 0.5 - Math.random()).slice(0, 5);
    }
};

export const generateGroupVentScript = async (config: LLMConfig, agents: Agent[], crisis: CrisisEvent, entropy: number, focusAgentId?: string, pastEvents: string[] = []): Promise<VentMessage[]> => {
  if (!config.apiKey && config.provider !== 'LOCAL') return fallbackScript(agents);

  // 1. Minify Agents to save tokens
  const agentMap = agents.map(a => {
      const isFocus = a.id === focusAgentId ? " [PRIMARY_VENTER]" : "";
      return `${a.id}:${a.role} [Current State: ${a.evolution}]${isFocus}`;
  }).join('\n');
  
  // 2. Logic for System Pressure
  let intensityInstruction = "Tense studio environment. Passive aggressive.";
  if (entropy > 75) intensityInstruction = "CRUNCH TIME MODE. Panic. People are quitting. Yelling.";
  if (entropy > 90) intensityInstruction = "STUDIO CLOSURE IMMINENT. Total breakdown. Nonsensical screaming. Burnout.";

  // 3. Historical Context
  const historyString = pastEvents.length > 0 
    ? `\nPREVIOUS STUDIO EVENTS (Reference these): ${pastEvents.join(' | ')}` 
    : "";

  // 4. Optimized Prompt
  const prompt = `SCENARIO: ${crisis.headline}. ${crisis.context}
STUDIO_STRESS: ${entropy}% (${intensityInstruction})
STAFF:
${agentMap}
${historyString}
${focusAgentId ? `FOCUS: Agent ${focusAgentId} is most affected and should lead the rant.` : ''}
TASK: Write 5-line dialogue script regarding this game dev crisis.
FORMAT: AgentID|Emotion|Text
NO MARKDOWN. NO JSON.`;

  try {
    const raw = await callLLM(config, prompt, "You are a Game Studio Scriptwriter. Cynical, realistic, tech-savvy.");
    return parseScript(raw, agents);
  } catch (error) {
    console.error("Script Gen Failed:", error);
    return fallbackScript(agents);
  }
};

export const continueGroupVentScript = async (config: LLMConfig, agents: Agent[], crisis: CrisisEvent, currentScript: VentMessage[], entropy: number): Promise<VentMessage[]> => {
  if (!config.apiKey && config.provider !== 'LOCAL') return [];

  // 1. Minify History (Last 3 lines only)
  const history = currentScript.slice(-3).map(m => `${m.agentId}: ${m.text}`).join('\n');
  
  let intensity = "Escalating arguments about game design.";
  if (entropy > 80) intensity = "Maximum toxicity. Threatening to leak the build.";

  const prompt = `TOPIC: ${crisis.headline}
HISTORY:
${history}
TASK: Write next 4 lines. ${intensity}
FORMAT: AgentID|Emotion|Text`;

  try {
    const raw = await callLLM(config, prompt, "You are a game dev scriptwriter. Escalating tension.");
    return parseScript(raw, agents);
  } catch (error) {
    return [];
  }
};

export const generateResolution = async (config: LLMConfig, agents: Agent[], crisis: CrisisEvent, script: VentMessage[]): Promise<Resolution> => {
    if (!config.apiKey && config.provider !== 'LOCAL') return { winnerId: agents[0].id, action: "SAFE MODE", reasoning: "Offline.", consensusScore: 10 };

    // 1. Minify Script for Analysis
    const minScript = script.map(m => `${m.agentId.split('-')[0]}:${m.text.substring(0, 50)}`).join('\n');

    const prompt = `Analyze studio debate:
${minScript}
Who won the argument? What is the studio's production decision?
Return JSON: { "winnerId": "exact_agent_id", "action": "string", "reasoning": "string", "consensusScore": number }
AgentIDs: ${agents.map(a => a.id).join(', ')}`;

    try {
        const raw = await callLLM(config, prompt, "You are a Studio Executive Judge.", true);
        // Sanitize JSON
        const jsonStr = raw.replace(/```json|```/g, '').trim();
        return JSON.parse(jsonStr);
    } catch (e) {
        return {
            winnerId: agents[0].id,
            action: "DELAY LAUNCH",
            reasoning: "Analysis failed.",
            consensusScore: 0
        };
    }
};

export const evolveAgents = async (config: LLMConfig, agents: Agent[], resolution: Resolution, crisis: CrisisEvent): Promise<Agent[]> => {
    if (!config.apiKey && config.provider !== 'LOCAL') return agents;

    const agentStats = agents.map(a => 
        `${a.id}: Wins=${a.wins}, Stress=${a.stressLevel}, Current=${a.evolution}`
    ).join('\n');

    const prompt = `Event: ${crisis.headline}. Winner: ${resolution.winnerId}.
STATS:
${agentStats}
RULES:
1. If Wins > 3, agent becomes arrogant.
2. If Stress > 80, agent becomes burnt out/toxic.
3. If Stress < 30, agent is suspiciously calm.
TASK: Update 1-sentence "evolution" state for all agents reflecting these stats.
Format: AgentID|NewStateString`;

    try {
        const raw = await callLLM(config, prompt, "Psychology Engine.");
        const lines = raw.split('\n');
        
        return agents.map(agent => {
            const line = lines.find(l => l.includes(agent.id));
            if (line) {
                const parts = line.split('|');
                if (parts.length >= 2) return { ...agent, evolution: parts[1].trim() };
            }
            return agent;
        });

    } catch (e) {
        return agents;
    }
};

export const archiveEpoch = async (config: LLMConfig, logs: VentLog[]): Promise<VentLog> => {
     if (!config.apiKey && config.provider !== 'LOCAL') throw new Error("No API");
     
     // Heavy compression
     const logText = logs.slice(-10).map(l => l.rawOutput.substring(0, 100)).join('\n');
     const prompt = `Summarize Studio Development Cycle (Epoch) based on logs:\n${logText}`;
     
     const text = await callLLM(config, prompt, "Studio Historian.");
     
     return {
        id: safeUUID(),
        agentId: 'HISTORIAN',
        timestamp: new Date().toISOString(),
        conflictType: 'EPOCH_ARCHIVE',
        priority: 'MEDIUM',
        rawOutput: text,
        pressureRelease: 100,
        isCompressed: true
    };
};

export const generateAgentAudio = async (text: string, voiceName: string = 'Zephyr', apiKey: string): Promise<string | null> => {
    if (!apiKey) return null;
    // Audio is strictly Gemini for now as other providers don't have standard TTS in this specific format
    try {
        const ai = new GoogleGenAI({ apiKey });
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-tts",
            contents: { parts: [{ text: text }] },
            config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName } } }
            }
        });
        return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || null;
    } catch (error) {
        return null;
    }
};

// --- HELPERS ---

function parseScript(raw: string, agents: Agent[]): VentMessage[] {
    return raw.split('\n')
        .filter(l => l.includes('|'))
        .map((line, i) => {
            const parts = line.split('|');
            // Fuzzy match agent ID
            const agentIdRaw = parts[0].trim().toLowerCase();
            const validId = agents.find(a => agentIdRaw.includes(a.id.split('-')[0].toLowerCase()))?.id || agents[0].id;
            
            return {
                id: safeUUID(),
                agentId: validId,
                emotion: parts[1]?.trim() || 'Neutral',
                text: parts[2]?.trim() || parts[1] || '...',
                timestamp: Date.now() + (i * 1000)
            };
        });
}

function fallbackScript(agents: Agent[]): VentMessage[] {
    // Pick 4 random agents
    const shuffled = [...agents].sort(() => 0.5 - Math.random()).slice(0, 4);
    
    return shuffled.map((agent, index) => ({
        id: safeUUID(),
        agentId: agent.id,
        text: `[OFFLINE] ${getRandomFallbackQuote(agent.id)}`,
        emotion: "Static",
        timestamp: Date.now() + (index * 1000)
    }));
}
