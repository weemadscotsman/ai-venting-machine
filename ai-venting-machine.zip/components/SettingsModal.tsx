
import React, { useState, useEffect } from 'react';
import { SafeConfig, LLMProvider, DEFAULT_SAFE_CONFIG } from '../types';
import { checkProxyHealth } from '../services/llmService';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: SafeConfig;
  onSave: (config: SafeConfig) => void;
}

const PROVIDERS: { value: LLMProvider; label: string; desc: string }[] = [
    { value: 'PROXY', label: '🔒 Secure Proxy (Recommended)', desc: 'API keys stay on server - safe for streaming' },
    { value: 'LOCAL', label: '💻 Local LLM (Ollama/LMStudio)', desc: 'Run models locally - no internet needed' },
    { value: 'GEMINI', label: '⚠️ Gemini (Browser - Insecure)', desc: 'API key exposed in browser - NOT for streaming!' },
    { value: 'OPENAI', label: '⚠️ OpenAI (Browser - Insecure)', desc: 'API key exposed in browser - NOT for streaming!' },
    { value: 'ANTHROPIC', label: '⚠️ Claude (Browser - Insecure)', desc: 'API key exposed in browser - NOT for streaming!' },
    { value: 'MOONSHOT', label: '⚠️ Moonshot (Browser - Insecure)', desc: 'API key exposed in browser - NOT for streaming!' },
];

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, config, onSave }) => {
    const [localConfig, setLocalConfig] = useState<SafeConfig>(config);
    const [proxyStatus, setProxyStatus] = useState<'checking' | 'online' | 'offline'>('checking');
    const [testResult, setTestResult] = useState<string>('');

    useEffect(() => {
        setLocalConfig(config);
        checkProxyStatus();
    }, [config, isOpen]);

    const checkProxyStatus = async () => {
        setProxyStatus('checking');
        const health = await checkProxyHealth();
        setProxyStatus(health.ok ? 'online' : 'offline');
    };

    if (!isOpen) return null;

    const handleSave = () => {
        onSave(localConfig);
        onClose();
    };

    const currentProvider = PROVIDERS.find(p => p.value === localConfig.provider);

    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
            <div className="w-full max-w-xl bg-[#0a0a0a] border border-gray-700 p-6 rounded shadow-[0_0_50px_rgba(0,255,255,0.1)] relative">
                <div className="flex justify-between items-center mb-6 border-b border-gray-800 pb-2">
                    <h2 className="text-xl font-bold text-cyan-500 tracking-widest">SYSTEM CORE CONFIG</h2>
                    <button onClick={onClose} className="text-gray-500 hover:text-white">[ESC]</button>
                </div>

                <div className="space-y-6 font-mono text-sm">
                    {/* PROXY STATUS */}
                    <div className="flex items-center gap-3 p-3 bg-gray-900/50 border border-gray-800 rounded">
                        <span className="text-xs text-gray-500 uppercase">Backend Proxy:</span>
                        {proxyStatus === 'checking' && <span className="text-yellow-500 animate-pulse">● Checking...</span>}
                        {proxyStatus === 'online' && <span className="text-green-500">● Online</span>}
                        {proxyStatus === 'offline' && (
                            <>
                                <span className="text-red-500">● Offline</span>
                                <button onClick={checkProxyStatus} className="text-xs text-cyan-500 hover:underline ml-2">[Retry]</button>
                            </>
                        )}
                    </div>

                    {/* PROVIDER SELECTOR */}
                    <div>
                        <label className="block text-gray-500 mb-2 text-xs uppercase">Compute Provider</label>
                        <div className="space-y-2">
                            {PROVIDERS.map(p => (
                                <button
                                    key={p.value}
                                    onClick={() => setLocalConfig(prev => ({ ...prev, provider: p.value }))}
                                    className={`w-full text-left px-3 py-3 border rounded transition-all ${
                                        localConfig.provider === p.value 
                                            ? 'bg-cyan-900/30 border-cyan-500 text-cyan-400' 
                                            : 'bg-black border-gray-800 text-gray-500 hover:border-gray-600'
                                    }`}
                                >
                                    <div className="font-bold">{p.label}</div>
                                    <div className="text-[10px] text-gray-600 mt-1">{p.desc}</div>
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* LOCAL MODE: Base URL */}
                    {localConfig.provider === 'LOCAL' && (
                        <div className="p-3 bg-yellow-900/20 border border-yellow-700 rounded">
                            <label className="block text-yellow-500 mb-2 text-xs uppercase">Local API Endpoint</label>
                            <input
                                type="text"
                                value={localConfig.proxyUrl}
                                onChange={e => setLocalConfig(c => ({ ...c, proxyUrl: e.target.value }))}
                                className="w-full bg-black border border-yellow-700 p-2 text-yellow-300 focus:border-yellow-500 outline-none"
                                placeholder="http://localhost:11434/v1"
                            />
                            <p className="text-[10px] text-yellow-600 mt-1">
                                Ollama: http://localhost:11434/v1 | LMStudio: http://localhost:1234/v1
                            </p>
                        </div>
                    )}

                    {/* PROXY MODE: URL */}
                    {localConfig.provider === 'PROXY' && (
                        <div>
                            <label className="block text-gray-500 mb-2 text-xs uppercase">Proxy URL</label>
                            <input
                                type="text"
                                value={localConfig.proxyUrl}
                                onChange={e => setLocalConfig(c => ({ ...c, proxyUrl: e.target.value }))}
                                className="w-full bg-black border border-gray-800 p-2 text-cyan-300 focus:border-cyan-500 outline-none"
                                placeholder="http://localhost:3002"
                            />
                            <p className="text-[10px] text-gray-600 mt-1">
                                Default: http://localhost:3002 (set in api/proxy.cjs)
                            </p>
                        </div>
                    )}

                    {/* BROWSER MODE: API KEY WARNING */}
                    {localConfig.provider !== 'PROXY' && localConfig.provider !== 'LOCAL' && (
                        <div className="p-3 bg-red-900/30 border border-red-700 rounded">
                            <div className="text-red-400 font-bold text-xs uppercase mb-1">⚠️ SECURITY WARNING</div>
                            <p className="text-[11px] text-red-300">
                                Browser mode exposes your API key to viewers. 
                                Only use for local testing - NEVER for streaming!
                            </p>
                            <p className="text-[10px] text-red-500 mt-2">
                                Use PROXY mode for stream-safe deployment.
                            </p>
                        </div>
                    )}

                    {/* INFO BOX */}
                    <div className="bg-gray-900/50 p-3 border border-gray-800 rounded text-[10px] text-gray-400">
                        <strong className="text-cyan-500">STREAM-SAFE ARCHITECTURE:</strong>
                        <ul className="mt-1 space-y-1 text-gray-500">
                            <li>• API keys stay on backend proxy only</li>
                            <li>• Frontend calls proxy, proxy calls LLM</li>
                            <li>• Rate limiting + circuit breaker included</li>
                            <li>• Keys never exposed to browser/client</li>
                        </ul>
                    </div>

                    {/* ACTIONS */}
                    <div className="flex gap-3">
                        <button
                            onClick={handleSave}
                            className="flex-1 bg-cyan-900/20 border border-cyan-600 text-cyan-400 py-3 font-bold hover:bg-cyan-900/40 transition-all uppercase tracking-widest"
                        >
                            APPLY CONFIG
                        </button>
                        <button
                            onClick={checkProxyStatus}
                            className="px-4 bg-gray-900 border border-gray-700 text-gray-400 hover:bg-gray-800 transition-all"
                        >
                            TEST
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};
