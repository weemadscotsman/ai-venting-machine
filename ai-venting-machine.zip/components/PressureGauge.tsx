
import React from 'react';

interface PressureGaugeProps {
  value: number; // 0-100
  label: string;
}

// Atmospheric states for entropy
const ENTROPY_STATES = [
  { threshold: 0, name: 'CALM', desc: 'Systems nominal', icon: '☀️', narrative: 'The studio breathes easy.' },
  { threshold: 20, name: 'AWARE', desc: 'Minor friction detected', icon: '☁️', narrative: 'Something shifts in the periphery.' },
  { threshold: 40, name: 'TENSE', desc: 'Pressure building', icon: '⚡', narrative: 'Conversations become clipped. Coffee consumption rises.' },
  { threshold: 60, name: 'STRESSED', desc: 'Critical mass approaching', icon: '🌩️', narrative: 'Email threads spawn sub-threads. Blame circulates.' },
  { threshold: 80, name: 'CRITICAL', desc: 'System failure imminent', icon: '🔥', narrative: 'Someone will snap. Someone always snaps.' },
  { threshold: 95, name: 'CATASTROPHIC', desc: 'Total collapse pending', icon: '☠️', narrative: 'The void opens its mouth. We are all floating.' },
];

export const PressureGauge: React.FC<PressureGaugeProps> = ({ value, label }) => {
  const currentState = ENTROPY_STATES.slice().reverse().find(s => value >= s.threshold) || ENTROPY_STATES[0];
  
  // Color calculation
  const getColor = (val: number) => {
    if (val < 50) return 'from-green-600 to-green-400';
    if (val < 80) return 'from-amber-600 to-amber-400';
    return 'from-red-700 to-red-500';
  };

  const getGlowColor = (val: number) => {
    if (val < 50) return 'shadow-green-500/20';
    if (val < 80) return 'shadow-amber-500/20';
    return 'shadow-red-500/40';
  };

  const getTextColor = (val: number) => {
    if (val < 50) return 'text-green-500';
    if (val < 80) return 'text-amber-500';
    return 'text-red-500';
  };

  return (
    <div className="flex flex-col gap-2 w-full p-4 border border-gray-800 bg-black/40 rounded-sm">
      {/* Header with icon */}
      <div className="flex justify-between items-start">
        <div className="flex items-center gap-2">
          <span className={`text-lg ${value > 80 ? 'animate-pulse' : ''}`}>{currentState.icon}</span>
          <div>
            <div className={`text-xs uppercase tracking-widest font-bold ${getTextColor(value)}`}>
              {label}
            </div>
            <div className="text-[10px] text-gray-500">{currentState.name}</div>
          </div>
        </div>
        <div className="text-right">
          <span className="text-2xl font-mono text-white">
            {Math.round(value)}<span className="text-xs text-gray-500">%</span>
          </span>
        </div>
      </div>
      
      {/* Gauge with atmospheric effect */}
      <div className="relative">
        <div className="h-5 bg-gray-900 w-full relative overflow-hidden border border-gray-700 rounded-sm">
          {/* CRT scanline effect */}
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-white/5 to-transparent animate-pulse pointer-events-none" 
               style={{ animationDuration: '3s' }} />
          
          {/* Warning stripes at high entropy */}
          {value > 80 && (
            <div className="absolute inset-0 opacity-30" 
                 style={{
                   background: 'repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(239, 68, 68, 0.3) 10px, rgba(239, 68, 68, 0.3) 20px)',
                   animation: 'slide 1s linear infinite'
                 }} />
          )}
          
          {/* Tick marks */}
          <div className="absolute inset-0 flex justify-between px-1 pointer-events-none z-10">
            {[...Array(10)].map((_, i) => (
              <div key={i} className="w-[1px] h-full bg-black/50" />
            ))}
          </div>
          
          {/* Fill bar */}
          <div 
            className={`h-full transition-all duration-700 ease-out bg-gradient-to-r ${getColor(value)} relative ${value > 60 ? 'shadow-lg ' + getGlowColor(value) : ''}`}
            style={{ width: `${value}%` }}
          >
            {/* Leading edge glow */}
            <div className="absolute right-0 top-0 bottom-0 w-2 bg-white/30 blur-sm" />
          </div>
        </div>
        
        {/* Threshold markers */}
        <div className="absolute top-0 left-[50%] h-full w-[1px] bg-amber-500/30 pointer-events-none" title="Tension Threshold" />
        <div className="absolute top-0 left-[80%] h-full w-[1px] bg-red-500/50 pointer-events-none" title="Critical Threshold" />
      </div>
      
      {/* Narrative storytelling text */}
      <div className={`text-[10px] italic ${getTextColor(value)} opacity-80 min-h-[1.5em]`}>
        "{currentState.narrative}"
      </div>
      
      {/* Status indicators */}
      <div className="flex justify-between text-[9px] text-gray-600 font-mono pt-1 border-t border-gray-800/50">
        <span className={value < 50 ? 'text-green-600' : ''}>CALM</span>
        <span className={value >= 50 && value < 80 ? 'text-amber-500' : ''}>TENSE</span>
        <span className={value >= 80 ? 'text-red-500 animate-pulse' : ''}>CRITICAL</span>
      </div>
    </div>
  );
};
