import React, { useState } from 'react';

interface LeverControlProps {
  onClick: () => void;
  onContinue: () => void;
  disabled: boolean;
  canContinue: boolean;
  label: string;
  cooldown?: number;
  isAutoMode: boolean;
  onToggleAuto: (val: boolean) => void;
}

export const LeverControl: React.FC<LeverControlProps> = ({ 
  onClick, 
  onContinue, 
  disabled, 
  canContinue, 
  label, 
  cooldown = 0,
  isAutoMode,
  onToggleAuto
}) => {
  const [pulled, setPulled] = useState(false);

  const handlePull = () => {
    if (disabled || isAutoMode) return;
    setPulled(true);
    setTimeout(() => {
      onClick();
      setTimeout(() => setPulled(false), 300);
    }, 200);
  };

  return (
    <div className="flex h-full w-full items-center gap-2">
      {/* Auto Toggle */}
      <div className="flex flex-col items-center gap-1">
        <span className={`text-[8px] font-bold uppercase ${isAutoMode ? 'text-red-500' : 'text-gray-600'}`}>
          {isAutoMode ? 'AUTO' : 'SINGLE'}
        </span>
        <button
          onClick={() => onToggleAuto(!isAutoMode)}
          className={`w-12 h-6 rounded-full border relative transition-all ${isAutoMode ? 'bg-red-900/50 border-red-500' : 'bg-gray-900 border-gray-700'}`}
        >
          <div className={`absolute top-0.5 w-4 h-4 rounded-full transition-all ${isAutoMode ? 'left-[calc(100%-1.1rem)] bg-red-500' : 'left-0.5 bg-gray-500'}`} />
        </button>
      </div>

      {/* Lever */}
      <div className="flex-1 h-full relative flex items-center justify-center">
        {/* Status Display */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 px-3 py-1 bg-black border border-gray-700 rounded text-[10px] font-mono text-green-500">
          {cooldown > 0 ? `WAIT ${cooldown}s` : disabled ? 'BUSY' : 'READY'}
        </div>
        
        {/* Lever Arm */}
        <div 
          className={`relative w-3 bg-gradient-to-b from-yellow-600 to-yellow-800 border border-yellow-900 rounded transition-transform duration-200 origin-bottom ${pulled ? 'rotate-45' : 'rotate-0'}`}
          style={{ height: '50px', marginTop: '10px' }}
        >
          {/* Knob */}
          <div 
            onClick={handlePull}
            className={`absolute -top-4 left-1/2 -translate-x-1/2 w-10 h-10 rounded-full bg-gradient-to-br from-red-500 to-red-900 border-2 border-red-400 cursor-pointer hover:scale-110 active:scale-95 transition-all ${disabled || isAutoMode ? 'opacity-40 grayscale' : ''}`}
          >
            <div className="absolute top-2 left-2 w-2 h-2 bg-red-300 rounded-full opacity-50" />
          </div>
        </div>

        {/* Cooldown bar */}
        {cooldown > 0 && (
          <div className="absolute bottom-0 w-32 h-1 bg-gray-800 rounded-full overflow-hidden">
            <div className="h-full bg-cyan-500 transition-all" style={{ width: `${(cooldown / 10) * 100}%` }} />
          </div>
        )}
      </div>

      {/* Extend Button */}
      <button
        onClick={onContinue}
        disabled={!canContinue || disabled}
        className={`h-14 w-14 rounded-full border-2 flex flex-col items-center justify-center transition-all ${!canContinue || disabled ? 'bg-gray-900 border-gray-800 text-gray-600' : 'bg-amber-700 border-amber-500 text-white hover:bg-amber-600'}`}
      >
        <span className="text-lg">↻</span>
        <span className="text-[8px] font-bold">EXTEND</span>
      </button>
    </div>
  );
};
