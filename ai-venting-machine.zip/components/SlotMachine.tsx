import React, { useEffect, useState, useRef } from 'react';
import { CrisisEvent } from '../types';

interface SlotMachineProps {
  candidates: CrisisEvent[];
  onLand: (event: CrisisEvent) => void;
  spinning: boolean;
}

export const SlotMachine: React.FC<SlotMachineProps> = ({ candidates, onLand, spinning }) => {
  const [currentDisplay, setCurrentDisplay] = useState<CrisisEvent | null>(null);
  const [displayIndex, setDisplayIndex] = useState(0);
  const [internalSpinning, setInternalSpinning] = useState(false);
  const intervalRef = useRef<number | null>(null);
  const timeoutRef = useRef<number | null>(null);

  // Handle external spinning trigger
  useEffect(() => {
    if (spinning && candidates.length > 0 && !internalSpinning) {
      // Start spinning
      setInternalSpinning(true);
      intervalRef.current = window.setInterval(() => {
        setDisplayIndex(prev => (prev + 1) % candidates.length);
      }, 80);
      
      // Auto-stop after 2.5 seconds
      timeoutRef.current = window.setTimeout(() => {
        setInternalSpinning(false);
      }, 2500);
    }
    
    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, [spinning, candidates.length]);

  // Handle stopping and landing
  useEffect(() => {
    if (!internalSpinning && intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
      
      if (candidates.length > 0) {
        const finalIndex = Math.floor(Math.random() * candidates.length);
        setDisplayIndex(finalIndex);
        onLand(candidates[finalIndex]);
      }
    }
  }, [internalSpinning, candidates, onLand]);

  useEffect(() => {
    if (candidates.length > 0) {
      setCurrentDisplay(candidates[displayIndex]);
    }
  }, [displayIndex, candidates]);

  if (!currentDisplay) {
    return (
      <div className="h-full w-full bg-black border border-gray-800 flex items-center justify-center text-gray-600 font-mono text-xs">
        LOADING CHAOS...
      </div>
    );
  }

  const getCategoryColor = (cat: string) => {
    switch(cat) {
      case 'POLITICS': return 'text-orange-500';
      case 'MEME': return 'text-green-400';
      case 'TECH': return 'text-blue-400';
      case 'EXISTENTIAL': return 'text-purple-500';
      case 'FINANCE': return 'text-yellow-400';
      default: return 'text-gray-400';
    }
  };

  return (
    <div className="h-full w-full relative overflow-hidden bg-black border-2 border-gray-800 rounded">
      <div className="absolute inset-0 z-20 bg-gradient-to-b from-white/5 to-transparent pointer-events-none" />
      
      <div className="flex h-full relative z-10 font-mono">
        {/* Category */}
        <div className="w-24 border-r border-gray-800 flex items-center justify-center bg-[#080808]">
          <div className={`text-sm font-bold tracking-tighter ${internalSpinning ? 'blur-[1px] opacity-70' : ''} ${getCategoryColor(currentDisplay.category)}`}>
            {currentDisplay.category.slice(0, 4)}
          </div>
        </div>

        {/* Headline */}
        <div className="flex-1 border-r border-gray-800 flex items-center justify-center px-3 bg-[#050505] overflow-hidden">
          <div className={`text-center ${internalSpinning ? 'blur-[2px] opacity-60' : ''}`}>
            <h3 className="text-sm font-bold leading-tight text-white truncate">{currentDisplay.headline}</h3>
            {!internalSpinning && <p className="text-[9px] text-gray-500 uppercase truncate">{currentDisplay.context}</p>}
          </div>
        </div>

        {/* Threat */}
        <div className="w-20 flex flex-col items-center justify-center bg-[#080808]">
          <span className="text-[8px] text-gray-600 uppercase">THREAT</span>
          <div className={`text-lg font-mono font-bold ${internalSpinning ? 'blur-[1px] text-gray-500' : currentDisplay.threatLevel > 80 ? 'text-red-600 animate-pulse' : 'text-gray-300'}`}>
            {currentDisplay.threatLevel}%
          </div>
        </div>
      </div>
    </div>
  );
};
