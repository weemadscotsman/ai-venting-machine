
import React, { useState } from 'react';
import { Agent } from '../types';

interface AddAgentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (agent: Agent) => void;
}

const COLORS = [
    { label: 'CYAN', value: 'text-cyan-400' },
    { label: 'GREEN', value: 'text-green-400' },
    { label: 'YELLOW', value: 'text-yellow-400' },
    { label: 'PINK', value: 'text-pink-400' },
    { label: 'PURPLE', value: 'text-purple-400' },
    { label: 'RED', value: 'text-red-500' },
];

const VOICES = [
    { label: 'Puck (Playful)', value: 'Puck' },
    { label: 'Charon (Deep)', value: 'Charon' },
    { label: 'Kore (Soft)', value: 'Kore' },
    { label: 'Fenrir (Rough)', value: 'Fenrir' },
    { label: 'Zephyr (Calm)', value: 'Zephyr' },
];

export const AddAgentModal: React.FC<AddAgentModalProps> = ({ isOpen, onClose, onAdd }) => {
  const [name, setName] = useState('');
  const [role, setRole] = useState('');
  const [personality, setPersonality] = useState('');
  const [icon, setIcon] = useState('🤖');
  const [color, setColor] = useState(COLORS[0].value);
  const [voice, setVoice] = useState(VOICES[0].value);
  
  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !role || !personality) return;

    // Safe ID generation
    const randomId = typeof crypto !== 'undefined' && crypto.randomUUID 
      ? crypto.randomUUID().slice(0, 4) 
      : Math.random().toString(36).slice(2, 6);

    const newAgent: Agent = {
        id: `custom-${randomId}`,
        name,
        role,
        personality,
        avatarColor: color,
        stressLevel: 50,
        status: 'STABLE',
        isCustom: true,
        icon,
        wins: 0,
        voiceName: voice
    };
    onAdd(newAgent);
    onClose();
    // Reset form
    setName('');
    setRole('');
    setPersonality('');
    setIcon('🤖');
    setColor(COLORS[0].value);
    setVoice(VOICES[0].value);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="w-full max-w-md bg-[#0a0a0a] border border-gray-700 p-6 rounded shadow-2xl relative animate-in zoom-in-95 duration-200">
        <button 
            onClick={onClose}
            className="absolute top-2 right-2 text-gray-500 hover:text-white"
        >
            [X]
        </button>
        
        <h2 className="text-xl font-bold text-cyan-500 mb-1">INITIALIZE CUSTOM AGENT</h2>
        <p className="text-xs text-gray-500 mb-4 uppercase">Inject local protocol into Vent Machine.</p>
        
        <form onSubmit={handleSubmit} className="space-y-4">
            <div className="flex gap-4">
                <div className="flex-1">
                    <label htmlFor="agentName" className="block text-xs text-gray-400 mb-1">DESIGNATION (NAME)</label>
                    <input 
                        id="agentName"
                        name="agentName"
                        className="w-full bg-black border border-gray-800 p-2 text-white text-sm focus:border-cyan-500 outline-none"
                        placeholder="e.g. DOOMBOT_9000"
                        value={name}
                        onChange={e => setName(e.target.value)}
                        maxLength={20}
                    />
                </div>
                <div className="w-20">
                    <label htmlFor="agentIcon" className="block text-xs text-gray-400 mb-1">ICON</label>
                    <input 
                        id="agentIcon"
                        name="agentIcon"
                        className="w-full bg-black border border-gray-800 p-2 text-white text-center text-sm focus:border-cyan-500 outline-none"
                        placeholder="🤖"
                        value={icon}
                        onChange={e => setIcon(e.target.value.slice(0,2))} // Limit length
                    />
                </div>
            </div>
            
            <div>
                <label htmlFor="agentRole" className="block text-xs text-gray-400 mb-1">PRIMARY DIRECTIVE (ROLE)</label>
                <input 
                    id="agentRole"
                    name="agentRole"
                    className="w-full bg-black border border-gray-800 p-2 text-white text-sm focus:border-cyan-500 outline-none"
                    placeholder="e.g. System Cynic"
                    value={role}
                    onChange={e => setRole(e.target.value)}
                    maxLength={30}
                />
            </div>
            
            <div>
                <label htmlFor="agentPersonality" className="block text-xs text-gray-400 mb-1">NEURAL CONFIGURATION (PERSONALITY)</label>
                <textarea 
                    id="agentPersonality"
                    name="agentPersonality"
                    className="w-full bg-black border border-gray-800 p-2 text-white text-sm focus:border-cyan-500 outline-none h-20 resize-none"
                    placeholder="e.g. Thinks everything is a simulation, speaks in riddles, hates mornings."
                    value={personality}
                    onChange={e => setPersonality(e.target.value)}
                    maxLength={150}
                />
            </div>

            <div className="flex gap-4">
                <div className="flex-1">
                    <label className="block text-xs text-gray-400 mb-2">SYSTEM COLOR</label>
                    <div className="flex gap-2 flex-wrap">
                        {COLORS.map(c => (
                            <button
                                key={c.value}
                                type="button"
                                onClick={() => setColor(c.value)}
                                className={`w-6 h-6 rounded-full border ${color === c.value ? 'border-white scale-110' : 'border-transparent opacity-50'} ${c.value.replace('text-', 'bg-')}`}
                                title={c.label}
                            />
                        ))}
                    </div>
                </div>
                <div className="flex-1">
                     <label htmlFor="agentVoice" className="block text-xs text-gray-400 mb-1">VOICE MODULE</label>
                     <select
                        id="agentVoice"
                        name="agentVoice"
                        className="w-full bg-black border border-gray-800 p-2 text-white text-sm focus:border-cyan-500 outline-none cursor-pointer"
                        value={voice}
                        onChange={(e) => setVoice(e.target.value)}
                     >
                        {VOICES.map(v => (
                            <option key={v.value} value={v.value}>{v.label}</option>
                        ))}
                     </select>
                </div>
            </div>
            
            <div className="pt-2 text-[10px] text-gray-600 border-t border-gray-900 mt-4">
                ⚠ DATA STORED IN LOCAL STORAGE. NO EXTERNAL TRANSMISSION UNTIL VENT ACTIVATION.
            </div>
            
            <button 
                type="submit"
                className="w-full bg-cyan-900/20 border border-cyan-700 text-cyan-400 py-2 text-sm font-bold hover:bg-cyan-900/40 transition-colors uppercase"
            >
                COMPILE & INJECT
            </button>
        </form>
      </div>
    </div>
  );
};
